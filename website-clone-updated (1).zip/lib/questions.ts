export type Choice = { letter: string; text: string }

export type Question = {
  id: number
  passage?: string
  prompt: string
  choices?: Choice[]
  spr?: boolean
}

export type Module = {
  section: 1 | 2
  sectionName: string
  module: 1 | 2
  moduleName: string
  durationSeconds: number
  questions: Question[]
}

const WORD_PROMPT = "Which choice completes the text with the most logical and precise word or phrase?"

// ----------------------- SECTION 1: READING & WRITING -----------------------

// Questions sourced from the College Board "Digital SAT Sample Questions and
// Answer Explanations" document (official Bluebook practice material).
const rwModule1: Question[] = [
  {
    id: 1,
    passage:
      "To dye wool, Navajo (Diné) weaver Lillie Taylor uses plants and vegetables from Arizona, where she lives. For example, she achieved the deep reds and browns featured in her 2003 rug In the Path of the Four Seasons by using Arizona dock roots, drying and grinding them before mixing the powder with water to create a dye bath. To intensify the appearance of certain colors, Taylor also sometimes mixes in clay obtained from nearby soil.",
    prompt: "Which choice best states the main idea of the text?",
    choices: [
      { letter: "A", text: "Reds and browns are not commonly featured in most of Taylor's rugs." },
      { letter: "B", text: "In the Path of the Four Seasons is widely acclaimed for its many colors and innovative weaving techniques." },
      { letter: "C", text: "Taylor draws on local resources in the approach she uses to dye wool." },
      { letter: "D", text: "Taylor finds it difficult to locate Arizona dock root in the desert." },
    ],
  },
  {
    id: 2,
    passage:
      "Jan Gimsa, Robert Sleigh, and Ulrike Gimsa have hypothesized that the sail-like structure running down the back of the dinosaur Spinosaurus aegyptiacus improved the animal's success in underwater pursuits of prey species capable of making quick, evasive movements. To evaluate their hypothesis, a second team of researchers constructed two battery-powered mechanical models of S. aegyptiacus, one with a sail and one without, and subjected the models to a series of identical tests in a water-filled tank.",
    prompt:
      "Which finding from the model tests, if true, would most strongly support Gimsa and colleagues' hypothesis?",
    choices: [
      { letter: "A", text: "The model with a sail took significantly longer to travel a specified distance while submerged than the model without a sail did." },
      { letter: "B", text: "The model with a sail displaced significantly more water while submerged than the model without a sail did." },
      { letter: "C", text: "The model with a sail had significantly less battery power remaining after completing the tests than the model without a sail did." },
      { letter: "D", text: "The model with a sail took significantly less time to complete a sharp turn while submerged than the model without a sail did." },
    ],
  },
  {
    id: 3,
    passage:
      "\"Ghosts of the Old Year\" is an early 1900s poem by James Weldon Johnson. In the poem, the speaker describes experiencing an ongoing cycle of anticipation followed by regretful reflection:",
    prompt: "Which quotation from \"Ghosts of the Old Year\" most effectively illustrates the claim?",
    choices: [
      { letter: "A", text: "\"The snow has ceased its fluttering flight, / The wind sunk to a whisper light, / An ominous stillness fills the night, / A pause—a hush.\"" },
      { letter: "B", text: "\"And so the years go swiftly by, / Each, coming, brings ambitions high, / And each, departing, leaves a sigh / Linked to the past.\"" },
      { letter: "C", text: "\"What does this brazen tongue declare, / That falling on the midnight air / Brings to my heart a sense of care / Akin to fright?\"" },
      { letter: "D", text: "\"It tells of many a squandered day, / Of slighted gems and treasured clay, / Of precious stores not laid away, / Of fields unreaped.\"" },
    ],
  },
  {
    id: 4,
    passage:
      "Georgia Tech roboticists De'Aira Bryant and Ayanna Howard, along with ethicist Jason Borenstein, were interested in people's perceptions of robots' competence. They recruited participants and asked them how likely they think it is that a robot could do the work required in various occupations. Participants' evaluations varied widely depending on which occupation was being considered; for example,\n\nLikelihood that robots can work effectively (% of participants):\nTelevision news anchor — unlikely 24, neutral 9, likely 67\nTeacher — unlikely 37, neutral 16, likely 47\nFirefighter — unlikely 62, neutral 9, likely 30\nSurgeon — unlikely 74, neutral 9, likely 16\nTour guide — unlikely 10, neutral 8, likely 82",
    prompt: "Which choice most effectively uses data from the table to complete the example?",
    choices: [
      { letter: "A", text: "82% of participants believe that it is somewhat or very likely that a robot could work effectively as a tour guide, but only 16% believe that it is somewhat or very likely that a robot could work as a surgeon." },
      { letter: "B", text: "47% of participants believe that it is somewhat or very likely that a robot could work effectively as a teacher, but 37% of respondents believe that it is somewhat or very unlikely that a robot could do so." },
      { letter: "C", text: "9% of participants were neutral about whether a robot could work effectively as a television news anchor, which is the same percent of participants who were neutral when asked about a robot working as a surgeon." },
      { letter: "D", text: "62% of participants believe that it is somewhat or very unlikely that a robot could work effectively as a firefighter." },
    ],
  },
  {
    id: 5,
    passage:
      "Many animals, including humans, must sleep, and sleep is known to have a role in everything from healing injuries to encoding information in long-term memory. But some scientists claim that, from an evolutionary standpoint, deep sleep for hours at a time leaves an animal so vulnerable that the known benefits of sleeping seem insufficient to explain why it became so widespread in the animal kingdom. These scientists therefore imply that",
    prompt: "Which choice most logically completes the text?",
    choices: [
      { letter: "A", text: "it is more important to understand how widespread prolonged deep sleep is than to understand its function." },
      { letter: "B", text: "prolonged deep sleep is likely advantageous in ways that have yet to be discovered." },
      { letter: "C", text: "many traits that provide significant benefits for an animal also likely pose risks to that animal." },
      { letter: "D", text: "most traits perform functions that are hard to understand from an evolutionary standpoint." },
    ],
  },
  {
    id: 6,
    passage:
      "In recommending Bao Phi's collection Sông I Sing, a librarian noted that pieces by the spoken-word poet don't lose their __________ nature when printed: the language has the same pleasant musical quality on the page as it does when performed by Phi.",
    prompt: WORD_PROMPT,
    choices: [
      { letter: "A", text: "jarring" },
      { letter: "B", text: "scholarly" },
      { letter: "C", text: "melodic" },
      { letter: "D", text: "personal" },
    ],
  },
  {
    id: 7,
    passage:
      "The following text is from F. Scott Fitzgerald's 1925 novel The Great Gatsby. [Jay Gatsby] was balancing himself on the dashboard of his car with that resourcefulness of movement that is so peculiarly American—that comes, I suppose, with the absence of lifting work in youth and, even more, with the formless grace of our nervous, sporadic games. This quality was continually breaking through his punctilious manner in the shape of restlessness.",
    prompt: "As used in the text, what does the word \"quality\" most nearly mean?",
    choices: [
      { letter: "A", text: "Characteristic" },
      { letter: "B", text: "Standard" },
      { letter: "C", text: "Prestige" },
      { letter: "D", text: "Accomplishment" },
    ],
  },
  {
    id: 8,
    passage:
      "The work of molecular biophysicist Enrique M. De La Cruz is known for __________ traditional boundaries between academic disciplines. The university laboratory that De La Cruz runs includes engineers, biologists, chemists, and physicists, and the research the lab produces makes use of insights and techniques from all those fields.",
    prompt: WORD_PROMPT,
    choices: [
      { letter: "A", text: "reinforcing" },
      { letter: "B", text: "anticipating" },
      { letter: "C", text: "epitomizing" },
      { letter: "D", text: "transcending" },
    ],
  },
  {
    id: 9,
    passage:
      "Some studies have suggested that posture can influence cognition, but we should not overstate this phenomenon. A case in point: In a 2014 study, Megan O'Brien and Alaa Ahmed had subjects stand or sit while making risky simulated economic decisions. Standing is more physically unstable and cognitively demanding than sitting; accordingly, O'Brien and Ahmed hypothesized that standing subjects would display more risk aversion during the decision-making tasks than sitting subjects did, since they would want to avoid further feelings of discomfort and complicated risk evaluations. But O'Brien and Ahmed actually found no difference in the groups' performance.",
    prompt: "Which choice best states the main purpose of the text?",
    choices: [
      { letter: "A", text: "It presents the study by O'Brien and Ahmed to critique the methods and results reported in previous studies of the effects of posture on cognition." },
      { letter: "B", text: "It argues that research findings about the effects of posture on cognition are often misunderstood, as in the case of O'Brien and Ahmed's study." },
      { letter: "C", text: "It explains a significant problem in the emerging understanding of posture's effects on cognition and how O'Brien and Ahmed tried to solve that problem." },
      { letter: "D", text: "It discusses the study by O'Brien and Ahmed to illustrate why caution is needed when making claims about the effects of posture on cognition." },
    ],
  },
  {
    id: 10,
    passage:
      "The following text is from Herman Melville's 1854 short story \"The Lightning-Rod Man.\" The stranger still stood in the exact middle of the cottage, where he had first planted himself. His singularity impelled a closer scrutiny. A lean, gloomy figure. Hair dark and lank, mattedly streaked over his brow. His sunken pitfalls of eyes were ringed by indigo halos, and played with an innocuous sort of lightning: the gleam without the bolt. The whole man was dripping. He stood in a puddle on the bare oak floor: his strange walking-stick vertically resting at his side.",
    prompt: "Which choice best states the function of the underlined sentence (\"His singularity impelled a closer scrutiny\") in the text as a whole?",
    choices: [
      { letter: "A", text: "It sets up the character description presented in the sentences that follow." },
      { letter: "B", text: "It establishes a contrast with the description in the previous sentence." },
      { letter: "C", text: "It elaborates on the previous sentence's description of the character." },
      { letter: "D", text: "It introduces the setting that is described in the sentences that follow." },
    ],
  },
  {
    id: 11,
    passage:
      "Text 1\nWhat factors influence the abundance of species in a given ecological community? Some theorists have argued that historical diversity is a major driver of how diverse an ecological community eventually becomes: differences in community diversity across otherwise similar habitats, in this view, are strongly affected by the number of species living in those habitats at earlier times.\n\nText 2\nIn 2010, a group of researchers including biologist Carla Cáceres created artificial pools in a New York forest. They stocked some pools with a diverse mix of zooplankton species and others with a single zooplankton species and allowed the pool communities to develop naturally thereafter. Over the course of four years, Cáceres and colleagues periodically measured the species diversity of the pools, finding—contrary to their expectations—that by the end of the study there was little to no difference in the pools' species diversity.",
    prompt:
      "Based on the texts, how would Cáceres and colleagues (Text 2) most likely describe the view of the theorists presented in Text 1?",
    choices: [
      { letter: "A", text: "It is largely correct, but it requires a minor refinement in light of the research team's results." },
      { letter: "B", text: "It is not compelling as a theory regardless of any experimental data collected by the research team." },
      { letter: "C", text: "It may seem plausible, but it is not supported by the research team's findings." },
      { letter: "D", text: "It probably holds true only in conditions like those in the research team's study." },
    ],
  },
  {
    id: 12,
    passage:
      "While researching a topic, a student has taken the following notes:\n• Maika'i Tubbs is a Native Hawaiian sculptor and installation artist.\n• His work has been shown in the United States, Canada, Japan, and Germany, among other places.\n• Many of his sculptures feature discarded objects.\n• His work Erasure (2008) includes discarded audiocassette tapes and magnets.\n• His work Home Grown (2009) includes discarded pushpins, plastic plates and forks, and wood.",
    prompt:
      "The student wants to emphasize a similarity between the two works. Which choice most effectively uses relevant information from the notes to accomplish this goal?",
    choices: [
      { letter: "A", text: "Erasure (2008) uses discarded objects such as audiocassette tapes and magnets; Home Grown (2009), however, includes pushpins, plastic plates and forks, and wood." },
      { letter: "B", text: "Like many of Tubbs's sculptures, both Erasure and Home Grown include discarded objects: Erasure uses audiocassette tapes, and Home Grown uses plastic forks." },
      { letter: "C", text: "Tubbs's work, which often features discarded objects, has been shown both within the United States and abroad." },
      { letter: "D", text: "Tubbs completed Erasure in 2008 and Home Grown in 2009." },
    ],
  },
  {
    id: 13,
    passage:
      "Iraqi artist Nazik Al-Malaika, celebrated as the first Arabic poet to write in free verse, didn't reject traditional forms entirely; her poem \"Elegy for a Woman of No Importance\" consists of two ten-line stanzas and a standard number of syllables. Even in this superficially traditional work, __________ Al-Malaika was breaking new ground by memorializing an anonymous woman rather than a famous man.",
    prompt: "Which choice completes the text with the most logical transition?",
    choices: [
      { letter: "A", text: "in fact," },
      { letter: "B", text: "though," },
      { letter: "C", text: "therefore," },
      { letter: "D", text: "moreover," },
    ],
  },
  {
    id: 14,
    passage:
      "According to Naomi Nakayama of the University of Edinburgh, the reason seeds from a dying dandelion appear to float in the air while __________ is that their porous plumes enhance drag, allowing the seeds to stay airborne long enough for the wind to disperse them throughout the surrounding area.",
    prompt: "Which choice completes the text so that it conforms to the conventions of Standard English?",
    choices: [
      { letter: "A", text: "falling," },
      { letter: "B", text: "falling:" },
      { letter: "C", text: "falling;" },
      { letter: "D", text: "falling" },
    ],
  },
  {
    id: 15,
    passage:
      "Rabinal Achí is a precolonial Maya dance drama performed annually in Rabinal, a town in the Guatemalan highlands. Based on events that occurred when Rabinal was a city-state ruled by a king, __________ had once been an ally of the king but was later captured while leading an invading force against him.",
    prompt: "Which choice completes the text so that it conforms to the conventions of Standard English?",
    choices: [
      { letter: "A", text: "Rabinal Achí tells the story of K'iche' Achí, a military leader who" },
      { letter: "B", text: "K'iche' Achí, the military leader in the story of Rabinal Achí," },
      { letter: "C", text: "there was a military leader, K'iche' Achí, who in Rabinal Achí" },
      { letter: "D", text: "the military leader whose story is told in Rabinal Achí, K'iche' Achí," },
    ],
  },
  {
    id: 16,
    passage:
      "Archaeologist Justin Jennings argues that the ancient Andean site of Cerro Baúl was a brewery as much as it was a settlement. Excavations there have uncovered large ceramic vessels capable of holding hundreds of liters of chicha, a fermented corn beverage, alongside evidence that elites gathered to consume it during important ceremonies.",
    prompt: "Which choice best states the main idea of the text?",
    choices: [
      { letter: "A", text: "Cerro Baúl produced more chicha than any other Andean site." },
      { letter: "B", text: "Chicha was consumed only by elites in ancient Andean societies." },
      { letter: "C", text: "Evidence suggests that brewing played a central role at Cerro Baúl." },
      { letter: "D", text: "The ceramic vessels at Cerro Baúl were used primarily for storage." },
    ],
  },
  {
    id: 17,
    passage:
      "Marine biologist Ayana Elizabeth Johnson has emphasized that protecting coastal ecosystems such as mangroves and salt marshes can help mitigate climate change. These ecosystems capture and store large amounts of carbon in their soils, a process sometimes called \"blue carbon\" storage.",
    prompt: "Which choice completes the text with the most logical and precise word or phrase?",
    choices: [
      { letter: "A", text: "release" },
      { letter: "B", text: "sequester" },
      { letter: "C", text: "displace" },
      { letter: "D", text: "ignore" },
    ],
  },
  {
    id: 18,
    passage:
      "The following text is adapted from Kate Chopin's 1899 novel The Awakening. The voice of the sea is seductive, never ceasing, whispering, clamoring, murmuring, inviting the soul to wander for a spell in abysses of solitude. The voice of the sea speaks to the soul. The touch of the sea is sensuous, enfolding the body in its soft, close embrace.",
    prompt: "Which choice best describes the function of the repetition of \"the voice of the sea\" in the text?",
    choices: [
      { letter: "A", text: "It emphasizes the sea's persistent, almost hypnotic influence on the soul." },
      { letter: "B", text: "It suggests that the sea is dangerous and should be avoided." },
      { letter: "C", text: "It contrasts the sea's appearance with its actual nature." },
      { letter: "D", text: "It indicates that the narrator fears the open water." },
    ],
  },
  {
    id: 19,
    passage:
      "A team of astronomers detected unusual radio signals emanating from a distant region of space. Before concluding that the signals had a natural origin, the researchers first ruled out the possibility that the signals were __________ by terrestrial sources such as cell towers or satellites.",
    prompt: "Which choice completes the text with the most logical and precise word or phrase?",
    choices: [
      { letter: "A", text: "generated" },
      { letter: "B", text: "received" },
      { letter: "C", text: "weakened" },
      { letter: "D", text: "interpreted" },
    ],
  },
  {
    id: 20,
    passage:
      "While studying a coral reef, researchers noticed that certain fish species changed color when approaching cleaning stations, where smaller fish remove parasites from larger ones. The researchers hypothesized that this color change __________ to the cleaner fish that the larger fish posed no threat.",
    prompt: "Which choice completes the text so that it conforms to the conventions of Standard English?",
    choices: [
      { letter: "A", text: "signal" },
      { letter: "B", text: "signals" },
      { letter: "C", text: "signaling" },
      { letter: "D", text: "to signal" },
    ],
  },
  {
    id: 21,
    passage:
      "Economist Esther Duflo has championed the use of randomized controlled trials to evaluate antipoverty programs. __________ traditional approaches that rely on intuition or anecdote, her method tests interventions rigorously by comparing groups that receive aid with those that do not.",
    prompt: "Which choice completes the text with the most logical transition?",
    choices: [
      { letter: "A", text: "Similar to" },
      { letter: "B", text: "Unlike" },
      { letter: "C", text: "Because of" },
      { letter: "D", text: "In addition to" },
    ],
  },
  {
    id: 22,
    passage:
      "The composer Florence Price became the first African American woman to have a symphony performed by a major American orchestra when the Chicago Symphony Orchestra played her Symphony in E minor in 1933. For decades afterward, however, her music was __________; it was only in 2009, when a trove of her manuscripts was discovered in an abandoned house, that interest in her work revived.",
    prompt: "Which choice completes the text with the most logical and precise word or phrase?",
    choices: [
      { letter: "A", text: "celebrated" },
      { letter: "B", text: "neglected" },
      { letter: "C", text: "performed" },
      { letter: "D", text: "published" },
    ],
  },
  {
    id: 23,
    passage:
      "While researching a topic, a student has taken the following notes:\n• The axolotl is a salamander native to lakes near Mexico City.\n• Unlike most amphibians, it retains larval features throughout its life.\n• It can regenerate lost limbs, parts of its heart, and even portions of its brain.\n• Scientists study it to understand tissue regeneration.\n• It is critically endangered in the wild.",
    prompt:
      "The student wants to emphasize the axolotl's regenerative abilities. Which choice most effectively uses relevant information from the notes to accomplish this goal?",
    choices: [
      { letter: "A", text: "The axolotl, a salamander native to lakes near Mexico City, is critically endangered in the wild." },
      { letter: "B", text: "Scientists study the axolotl, which retains larval features throughout its life, unlike most amphibians." },
      { letter: "C", text: "The axolotl can regenerate lost limbs, parts of its heart, and even portions of its brain, making it valuable to scientists studying tissue regeneration." },
      { letter: "D", text: "The axolotl is a salamander that retains larval features and lives near Mexico City." },
    ],
  },
  {
    id: 24,
    passage:
      "Text 1\nSome historians argue that the printing press was the single most important catalyst of the Protestant Reformation, since it allowed Martin Luther's writings to spread across Europe with unprecedented speed.\n\nText 2\nHistorian Andrew Pettegree cautions against overstating the press's role. He notes that many regions with abundant printing remained Catholic, and that Luther's success depended heavily on local political support and preexisting religious grievances that printing alone could not create.",
    prompt:
      "Based on the texts, how would Pettegree (Text 2) most likely respond to the historians described in Text 1?",
    choices: [
      { letter: "A", text: "By agreeing that printing was the sole cause of the Reformation." },
      { letter: "B", text: "By arguing that printing had no effect on the spread of Luther's ideas." },
      { letter: "C", text: "By contending that factors beyond printing were essential to the Reformation's success." },
      { letter: "D", text: "By claiming that the Reformation would have spread faster without the printing press." },
    ],
  },
  {
    id: 25,
    passage:
      "The novelist's prose is admirably __________: she conveys complex emotional states in just a few carefully chosen words, never indulging in the lengthy descriptions favored by many of her contemporaries.",
    prompt: "Which choice completes the text with the most logical and precise word or phrase?",
    choices: [
      { letter: "A", text: "ornate" },
      { letter: "B", text: "economical" },
      { letter: "C", text: "rambling" },
      { letter: "D", text: "ambiguous" },
    ],
  },
  {
    id: 26,
    passage:
      "Researchers studying honeybee communication found that foraging bees perform a \"waggle dance\" to indicate the direction and distance of food sources to their hivemates. The angle of the dance relative to vertical corresponds to the direction of the food relative to the sun, while the duration of the waggle phase __________ the distance to the food.",
    prompt: "Which choice completes the text with the most logical and precise word or phrase?",
    choices: [
      { letter: "A", text: "conceals" },
      { letter: "B", text: "encodes" },
      { letter: "C", text: "shortens" },
      { letter: "D", text: "doubts" },
    ],
  },
  {
    id: 27,
    passage:
      "The following text is adapted from Charlotte Perkins Gilman's 1892 short story \"The Yellow Wallpaper.\" The narrator, confined to a room for rest, describes the wallpaper. It is dull enough to confuse the eye in following, pronounced enough to constantly irritate and provoke study, and when you follow the lame uncertain curves for a little distance they suddenly commit suicide—plunge off at outrageous angles, destroy themselves in unheard-of contradictions.",
    prompt: "Which choice best describes the function of the underlined phrase (\"commit suicide\") in the text?",
    choices: [
      { letter: "A", text: "It uses vivid personification to convey the chaotic, disturbing quality of the wallpaper's pattern." },
      { letter: "B", text: "It establishes that the narrator finds the wallpaper soothing and pleasant." },
      { letter: "C", text: "It introduces a literal description of how the wallpaper was manufactured." },
      { letter: "D", text: "It indicates that the narrator intends to remove the wallpaper." },
    ],
  },
]

const rwModule2: Question[] = [
  {
    id: 1,
    passage:
      "Far from being a setback, the failure of the first prototype proved __________: the lessons engineers learned from its flaws directly informed the wildly successful design that followed.",
    prompt: WORD_PROMPT,
    choices: [
      { letter: "A", text: "instructive" },
      { letter: "B", text: "disastrous" },
      { letter: "C", text: "meaningless" },
      { letter: "D", text: "discouraging" },
    ],
  },
  {
    id: 2,
    passage:
      "The ancient irrigation system was remarkably __________, continuing to deliver water to the fields for over a thousand years with only minimal maintenance from the communities it served.",
    prompt: WORD_PROMPT,
    choices: [
      { letter: "A", text: "fragile" },
      { letter: "B", text: "durable" },
      { letter: "C", text: "wasteful" },
      { letter: "D", text: "decorative" },
    ],
  },
  {
    id: 3,
    passage:
      "The critic admitted that her first impression had been __________; what she had initially dismissed as a clumsy amateur film revealed, on a second viewing, a careful intelligence behind every shot.",
    prompt: WORD_PROMPT,
    choices: [
      { letter: "A", text: "accurate" },
      { letter: "B", text: "mistaken" },
      { letter: "C", text: "generous" },
      { letter: "D", text: "thorough" },
    ],
  },
  {
    id: 4,
    passage:
      "Because the desert receives so little rainfall, the plants that survive there have evolved __________ adaptations, such as waxy coatings and deep roots, that allow them to conserve every available drop of water.",
    prompt: WORD_PROMPT,
    choices: [
      { letter: "A", text: "wasteful" },
      { letter: "B", text: "ingenious" },
      { letter: "C", text: "harmful" },
      { letter: "D", text: "temporary" },
    ],
  },
  {
    id: 5,
    passage:
      "The professor encouraged her students to remain __________ when reading historical sources, reminding them that even seemingly factual accounts may reflect the biases and interests of those who wrote them.",
    prompt: WORD_PROMPT,
    choices: [
      { letter: "A", text: "skeptical" },
      { letter: "B", text: "credulous" },
      { letter: "C", text: "indifferent" },
      { letter: "D", text: "passive" },
    ],
  },
  {
    id: 6,
    passage:
      "The startup's rapid growth was ultimately __________: by expanding into too many markets at once, the company stretched its resources so thin that it could no longer maintain quality anywhere.",
    prompt: WORD_PROMPT,
    choices: [
      { letter: "A", text: "sustainable" },
      { letter: "B", text: "unsustainable" },
      { letter: "C", text: "profitable" },
      { letter: "D", text: "gradual" },
    ],
  },
  {
    id: 7,
    passage:
      "The diplomat was admired for her __________ approach to negotiation: she listened patiently to every party, acknowledged each concern, and sought solutions that allowed everyone to leave the table satisfied.",
    prompt: WORD_PROMPT,
    choices: [
      { letter: "A", text: "aggressive" },
      { letter: "B", text: "conciliatory" },
      { letter: "C", text: "dismissive" },
      { letter: "D", text: "rigid" },
    ],
  },
  {
    id: 8,
    passage:
      "The artist's later works mark a clear __________ from her early style: gone are the bright colors and bold lines, replaced by muted tones and delicate, almost hesitant brushstrokes.",
    prompt: WORD_PROMPT,
    choices: [
      { letter: "A", text: "departure" },
      { letter: "B", text: "continuation" },
      { letter: "C", text: "imitation" },
      { letter: "D", text: "endorsement" },
    ],
  },
  {
    id: 9,
    passage:
      "The evidence for the theory remains __________; while several studies support it, others have produced conflicting results, and researchers caution that no firm conclusion can yet be drawn.",
    prompt: WORD_PROMPT,
    choices: [
      { letter: "A", text: "conclusive" },
      { letter: "B", text: "inconclusive" },
      { letter: "C", text: "overwhelming" },
      { letter: "D", text: "fabricated" },
    ],
  },
  {
    id: 10,
    passage:
      "Rather than relying on memory alone, the explorer kept a __________ journal, recording precise measurements, dates, and observations that would later prove invaluable to scientists studying the region.",
    prompt: WORD_PROMPT,
    choices: [
      { letter: "A", text: "careless" },
      { letter: "B", text: "meticulous" },
      { letter: "C", text: "fictional" },
      { letter: "D", text: "sporadic" },
    ],
  },
  {
    id: 11,
    passage:
      "Quantum computing researchers face a fundamental challenge: the qubits that power quantum calculations are extremely __________ to environmental interference. Even tiny vibrations or temperature fluctuations can cause errors, forcing scientists to develop elaborate shielding systems to maintain computational accuracy.",
    prompt: WORD_PROMPT,
    choices: [
      { letter: "A", text: "resistant" },
      { letter: "B", text: "susceptible" },
      { letter: "C", text: "indifferent" },
      { letter: "D", text: "conducive" },
    ],
  },
  {
    id: 12,
    passage:
      "A recent study examined how the presence of background music affects reading comprehension. Participants were asked to read and answer questions about complex passages under three conditions: silence, instrumental music, and music with lyrics. Those in the silent condition performed best, while those listening to music with lyrics scored significantly lower. Participants listening to instrumental music performed only slightly below the silent group.",
    prompt:
      "Which finding, if true, would most directly weaken the conclusion that lyrics specifically impair reading comprehension?",
    choices: [
      { letter: "A", text: "Participants who regularly listen to music while studying performed equally poorly across all three conditions." },
      { letter: "B", text: "The passages used in the lyrics condition were significantly more difficult than those used in the other conditions." },
      { letter: "C", text: "Background conversation without music produces similar declines in comprehension as music with lyrics." },
      { letter: "D", text: "Participants reported enjoying the instrumental music more than the music with lyrics." },
    ],
  },
  {
    id: 13,
    passage:
      "The poet's use of enjambment — carrying a sentence across line breaks without punctuation — creates a sense of breathless momentum in the poem. This technique mirrors the speaker's emotional state, as the lines rush forward just as the speaker's thoughts tumble over one another in a moment of __________.",
    prompt: WORD_PROMPT,
    choices: [
      { letter: "A", text: "tranquility" },
      { letter: "B", text: "agitation" },
      { letter: "C", text: "indifference" },
      { letter: "D", text: "satisfaction" },
    ],
  },
  {
    id: 14,
    passage:
      "Economists have long debated whether raising the minimum wage leads to higher unemployment. A landmark study by Card and Krueger in the 1990s compared fast-food employment in New Jersey, which had raised its minimum wage, with neighboring Pennsylvania, which had not. Contrary to classical economic predictions, they found no significant decrease in employment in New Jersey. Critics, however, questioned the study's methodology, arguing that the researchers relied on telephone surveys rather than official payroll data.",
    prompt: "What role does the last sentence play in the text?",
    choices: [
      { letter: "A", text: "It provides evidence that confirms the study's central finding." },
      { letter: "B", text: "It explains why the researchers chose their particular methodology." },
      { letter: "C", text: "It raises a methodological concern about the study described earlier in the text." },
      { letter: "D", text: "It summarizes the broader economic debate about minimum wage policy." },
    ],
  },
  {
    id: 15,
    passage:
      "Although the two artists were contemporaries who worked in the same city, their approaches to painting were __________. Rivera favored large-scale murals depicting social and political themes, while Tamayo preferred intimate canvases exploring abstract forms and vibrant color harmonies.",
    prompt: WORD_PROMPT,
    choices: [
      { letter: "A", text: "identical" },
      { letter: "B", text: "complementary" },
      { letter: "C", text: "divergent" },
      { letter: "D", text: "derivative" },
    ],
  },
  {
    id: 16,
    passage:
      "A paleontologist studying fossilized trackways in Colorado discovered a series of footprints indicating that a group of large herbivorous dinosaurs traveled in a coordinated formation, with juveniles positioned at the center and adults at the perimeter. This arrangement is strikingly similar to the defensive formations used by modern elephants and musk oxen.",
    prompt: "What is the most likely reason the author mentions modern elephants and musk oxen?",
    choices: [
      { letter: "A", text: "To show that herbivorous dinosaurs were ancestors of modern mammals." },
      { letter: "B", text: "To suggest that the observed formation served a protective purpose." },
      { letter: "C", text: "To argue that modern animals are more intelligent than dinosaurs were." },
      { letter: "D", text: "To illustrate that fossil evidence is unreliable without modern comparisons." },
    ],
  },
  {
    id: 17,
    passage:
      "The journalist's reporting style was anything but __________. Her articles were meticulously researched, packed with verified sources, and presented with scrupulous attention to factual accuracy, earning her a reputation as one of the most trustworthy voices in investigative journalism.",
    prompt: WORD_PROMPT,
    choices: [
      { letter: "A", text: "thorough" },
      { letter: "B", text: "credible" },
      { letter: "C", text: "slipshod" },
      { letter: "D", text: "acclaimed" },
    ],
  },
  {
    id: 18,
    passage:
      "A sociologist studying workplace dynamics found that teams with moderate levels of disagreement consistently outperformed teams with either very high or very low levels of conflict. She theorized that some disagreement pushes team members to examine their assumptions and consider alternative approaches, while excessive conflict undermines trust and cooperation.",
    prompt: "Which choice best describes the relationship between disagreement and team performance as presented in the text?",
    choices: [
      { letter: "A", text: "There is a direct positive relationship: more disagreement always leads to better performance." },
      { letter: "B", text: "There is an inverse relationship: any amount of disagreement reduces performance." },
      { letter: "C", text: "The relationship follows a curved pattern, with moderate levels being optimal." },
      { letter: "D", text: "The relationship is random and unpredictable across different team compositions." },
    ],
  },
  {
    id: 19,
    passage:
      "In his memoir, the mountaineer describes the summit attempt not as a moment of triumph but as one of profound __________. Exhausted and oxygen-deprived at 28,000 feet, he felt not elation but a deep awareness of his own fragility against the vast, indifferent landscape.",
    prompt: WORD_PROMPT,
    choices: [
      { letter: "A", text: "exhilaration" },
      { letter: "B", text: "humility" },
      { letter: "C", text: "resentment" },
      { letter: "D", text: "confusion" },
    ],
  },
  {
    id: 20,
    passage:
      "Text 1: Literary critic Harold Bloom argued that Shakespeare invented the modern conception of human personality. Before Shakespeare, Bloom contended, literary characters did not evolve or reflect on their own natures; it was Shakespeare who first created characters capable of genuine self-awareness and internal transformation. Text 2: Scholar Margreta de Grazia challenges Bloom's claim by pointing to medieval mystery plays and Chaucer's Canterbury Tales, both of which feature characters who undergo significant psychological development. She argues that attributing the invention of personality to a single author ignores centuries of literary experimentation.",
    prompt: "Based on the texts, how would de Grazia most likely respond to Bloom's central claim?",
    choices: [
      { letter: "A", text: "By arguing that Shakespeare's characters are less complex than Bloom suggests." },
      { letter: "B", text: "By pointing out that psychological complexity in literature predates Shakespeare." },
      { letter: "C", text: "By suggesting that the concept of personality is irrelevant to literary analysis." },
      { letter: "D", text: "By agreeing with Bloom but adding that Shakespeare was influenced by medieval writers." },
    ],
  },
  {
    id: 21,
    passage:
      "The new museum exhibition takes a __________ approach to its subject matter, combining artifacts, interactive displays, video installations, and live performances rather than relying on any single medium to tell the story of the civil rights movement.",
    prompt: WORD_PROMPT,
    choices: [
      { letter: "A", text: "conventional" },
      { letter: "B", text: "restrictive" },
      { letter: "C", text: "multifaceted" },
      { letter: "D", text: "superficial" },
    ],
  },
  {
    id: 22,
    passage:
      "Neuroscientists have discovered that the brain's hippocampus, long known for its role in memory formation, also functions as a kind of internal GPS. Specialized neurons called \"place cells\" fire in specific patterns depending on an individual's location in a physical space. This discovery, which earned researchers John O'Keefe, May-Britt Moser, and Edvard Moser the Nobel Prize in 2014, has implications for understanding Alzheimer's disease, which often affects spatial navigation before memory loss becomes apparent.",
    prompt: "According to the text, what is the significance of place cells to Alzheimer's research?",
    choices: [
      { letter: "A", text: "They suggest that Alzheimer's may first impair navigation abilities rather than memory." },
      { letter: "B", text: "They prove that Alzheimer's disease originates in the hippocampus." },
      { letter: "C", text: "They demonstrate that spatial navigation and memory are completely unrelated functions." },
      { letter: "D", text: "They explain why Alzheimer's patients can remember locations but not events." },
    ],
  },
  {
    id: 23,
    passage:
      "While the governor publicly praised the bipartisan nature of the new legislation, her private communications revealed a more __________ assessment. In emails to advisors, she described the bill as a series of painful concessions that achieved far less than what she had originally envisioned.",
    prompt: WORD_PROMPT,
    choices: [
      { letter: "A", text: "optimistic" },
      { letter: "B", text: "enthusiastic" },
      { letter: "C", text: "guarded" },
      { letter: "D", text: "candid" },
    ],
  },
  {
    id: 24,
    passage:
      "A research team tracked the migration patterns of Arctic terns for five consecutive years using lightweight GPS transmitters. The data revealed that the birds did not follow the same route each year; instead, they adjusted their flight paths based on prevailing wind patterns. In years with stronger tailwinds along the eastern Atlantic route, more birds chose that path, while in calmer years, many shifted to a route over the mid-Atlantic.",
    prompt: "Based on the text, what can be inferred about Arctic tern migration?",
    choices: [
      { letter: "A", text: "Arctic terns migrate primarily to escape predators rather than to find food." },
      { letter: "B", text: "The birds' route selection is influenced by atmospheric conditions they encounter." },
      { letter: "C", text: "Younger birds are more likely than older birds to change their migration routes." },
      { letter: "D", text: "GPS transmitters significantly altered the natural behavior of the birds studied." },
    ],
  },
  {
    id: 25,
    passage:
      "The playwright's early works were largely __________ by audiences and critics alike, filling theaters to capacity and earning enthusiastic reviews. It was only after her death that scholars began to identify the darker thematic undercurrents running beneath the comedic surfaces of her plays.",
    prompt: WORD_PROMPT,
    choices: [
      { letter: "A", text: "dismissed" },
      { letter: "B", text: "analyzed" },
      { letter: "C", text: "celebrated" },
      { letter: "D", text: "misunderstood" },
    ],
  },
  {
    id: 26,
    passage:
      "Ecologist Dr. Tanaka's research demonstrates that controlled forest fires, far from being purely destructive, play a vital role in maintaining ecosystem health. These fires clear accumulated dead vegetation, return nutrients to the soil, and create open spaces that allow sunlight to reach the forest floor, promoting the growth of native plant species that would otherwise be crowded out by the dense canopy above.",
    prompt: "Which choice best states the main purpose of the text?",
    choices: [
      { letter: "A", text: "To argue that all forest fires should be allowed to burn without human intervention." },
      { letter: "B", text: "To explain how controlled fires contribute positively to forest ecosystems." },
      { letter: "C", text: "To compare the effects of natural fires with those of fires started by humans." },
      { letter: "D", text: "To describe the specific plant species that benefit most from forest fires." },
    ],
  },
  {
    id: 27,
    passage:
      "The CEO's decision to restructure the company was not made __________. She spent eighteen months consulting with industry experts, analyzing market projections, and surveying employees at every level before announcing the plan, ensuring that the transformation was grounded in thorough research rather than reactive impulse.",
    prompt: WORD_PROMPT,
    choices: [
      { letter: "A", text: "strategically" },
      { letter: "B", text: "hastily" },
      { letter: "C", text: "publicly" },
      { letter: "D", text: "reluctantly" },
    ],
  },
]

// ----------------------- SECTION 2: MATH -----------------------

const mathModule1: Question[] = [
  // Q1 Algebra — linear
  { id: 1, prompt: "If 3x + 7 = 22, what is the value of x?", choices: [
    { letter: "A", text: "3" }, { letter: "B", text: "5" }, { letter: "C", text: "7" }, { letter: "D", text: "15" } ] },
  // Q2 Algebra — slope
  { id: 2, prompt: "A line in the xy-plane passes through the points (0, 4) and (2, 10). What is the slope of the line?", choices: [
    { letter: "A", text: "2" }, { letter: "B", text: "3" }, { letter: "C", text: "4" }, { letter: "D", text: "6" } ] },
  // Q3 Advanced Math — function evaluation
  { id: 3, prompt: "If f(x) = 2x² − 3x + 1, what is the value of f(3)?", choices: [
    { letter: "A", text: "8" }, { letter: "B", text: "10" }, { letter: "C", text: "12" }, { letter: "D", text: "16" } ] },
  // Q4 Advanced Math — equivalent expression
  { id: 4, prompt: "The expression 5(2x − 3) − 4x is equivalent to which of the following?", choices: [
    { letter: "A", text: "6x − 15" }, { letter: "B", text: "6x − 3" }, { letter: "C", text: "14x − 15" }, { letter: "D", text: "6x + 15" } ] },
  // Q5 PSDA — word problem (linear model)
  { id: 5, prompt: "A bookstore sells notebooks for $3 each and charges a flat $2 shipping fee per order. If a student buys n notebooks in a single order, which expression represents the total cost, in dollars?", choices: [
    { letter: "A", text: "3n" }, { letter: "B", text: "3n + 2" }, { letter: "C", text: "2n + 3" }, { letter: "D", text: "5n" } ] },
  // Q6 PSDA — word problem (percent)
  { id: 6, prompt: "A marine biologist surveyed a coral reef and found that 40% of the fish she counted were parrotfish. If she counted 60 parrotfish, how many fish did she count in total?", choices: [
    { letter: "A", text: "100" }, { letter: "B", text: "120" }, { letter: "C", text: "150" }, { letter: "D", text: "240" } ] },
  // Q7 Algebra — linear equation
  { id: 7, prompt: "What is the value of x if 2(x − 4) = x + 1?", choices: [
    { letter: "A", text: "3" }, { letter: "B", text: "7" }, { letter: "C", text: "9" }, { letter: "D", text: "11" } ] },
  // Q8 Algebra — function
  { id: 8, prompt: "The function g is defined by g(x) = 4x − 5. For what value of x does g(x) = 11?", choices: [
    { letter: "A", text: "1.5" }, { letter: "B", text: "4" }, { letter: "C", text: "6" }, { letter: "D", text: "16" } ] },
  // Q9 Geometry — circle area
  { id: 9, prompt: "A circle has a radius of 5. What is its area? (Use π ≈ 3.14)", choices: [
    { letter: "A", text: "15.7" }, { letter: "B", text: "31.4" }, { letter: "C", text: "78.5" }, { letter: "D", text: "157" } ] },
  // Q10 Advanced Math (square root)
  { id: 10, prompt: "If x² = 49 and x > 0, what is the value of x?", choices: [
    { letter: "A", text: "−7" }, { letter: "B", text: "7" }, { letter: "C", text: "24.5" }, { letter: "D", text: "2401" } ] },
  // Q11 PSDA — word problem (ratio/proportion)
  { id: 11, prompt: "A bakery's bread recipe requires 2 cups of flour for every 3 cups of sugar. A baker is scaling up the recipe and plans to use 12 cups of sugar. How many cups of flour will be needed?", choices: [
    { letter: "A", text: "6" }, { letter: "B", text: "8" }, { letter: "C", text: "9" }, { letter: "D", text: "18" } ] },
  // Q12 Algebra — order of operations
  { id: 12, prompt: "What is the value of 7 + 4(2)?", choices: [
    { letter: "A", text: "15" }, { letter: "B", text: "18" }, { letter: "C", text: "22" }, { letter: "D", text: "30" } ] },
  // Q13 Algebra (substitution)
  { id: 13, prompt: "If 2x − y = 10 and y = 4, what is the value of x?", choices: [
    { letter: "A", text: "3" }, { letter: "B", text: "7" }, { letter: "C", text: "12" }, { letter: "D", text: "14" } ] },
  // Q14 Geometry — triangle angle
  { id: 14, prompt: "A triangle has angles measuring 40° and 75°. What is the measure of the third angle?", choices: [
    { letter: "A", text: "55°" }, { letter: "B", text: "65°" }, { letter: "C", text: "75°" }, { letter: "D", text: "115°" } ] },
  // Q15 PSDA — word problem (percent discount)
  { id: 15, prompt: "A jacket originally priced at $80 is on sale for 25% off. What is the sale price of the jacket?", choices: [
    { letter: "A", text: "$20" }, { letter: "B", text: "$55" }, { letter: "C", text: "$60" }, { letter: "D", text: "$75" } ] },
  // Q16 Algebra — linear
  { id: 16, prompt: "If 5x = 3x + 12, what is the value of x?", choices: [
    { letter: "A", text: "3" }, { letter: "B", text: "4" }, { letter: "C", text: "6" }, { letter: "D", text: "12" } ] },
  // Q17 Advanced Math — factoring
  { id: 17, prompt: "Which of the following is equivalent to 4x + 8?", choices: [
    { letter: "A", text: "4(x + 2)" }, { letter: "B", text: "4(x + 8)" }, { letter: "C", text: "2(2x + 8)" }, { letter: "D", text: "8(x + 4)" } ] },
  // Q18 PSDA — word problem (rate)
  { id: 18, prompt: "During a road trip, a car uses 4 gallons of gasoline to travel 120 miles. At this same rate, how many miles can the car travel using 7 gallons of gasoline?", choices: [
    { letter: "A", text: "180" }, { letter: "B", text: "210" }, { letter: "C", text: "240" }, { letter: "D", text: "280" } ] },
  // Q19 Algebra — interpret intercept
  { id: 19, prompt: "If the equation of a line is y = 3x − 2, what is the y-intercept?", choices: [
    { letter: "A", text: "−2" }, { letter: "B", text: "0" }, { letter: "C", text: "2" }, { letter: "D", text: "3" } ] },
  // Q20 Advanced Math — exponents
  { id: 20, prompt: "What is the value of (2³)(2²)?", choices: [
    { letter: "A", text: "16" }, { letter: "B", text: "32" }, { letter: "C", text: "64" }, { letter: "D", text: "256" } ] },
  // Q21 Geometry (perimeter from area)
  { id: 21, prompt: "A square has an area of 64 square units. What is its perimeter?", choices: [
    { letter: "A", text: "16" }, { letter: "B", text: "24" }, { letter: "C", text: "32" }, { letter: "D", text: "64" } ] },
  // Q22 PSDA word problem (unit rate)
  { id: 22, prompt: "A printer produces pages at a constant rate, printing 90 pages in 3 minutes. At this rate, how many pages does the printer produce in 7 minutes?", choices: [
    { letter: "A", text: "180" }, { letter: "B", text: "210" }, { letter: "C", text: "270" }, { letter: "D", text: "630" } ] },
]

const mathModule2: Question[] = [
  // Q1 Advanced Math — word problem: exponential growth
  { id: 1, prompt: "A biologist introduces 300 fish into a newly stocked lake. The population is modeled by the function P(t) = 300(1.2)^t, where t is the number of years after the fish were introduced. Which of the following best describes the population's behavior over time?", choices: [
    { letter: "A", text: "It decreases by 20% each year." },
    { letter: "B", text: "It increases by 20% each year." },
    { letter: "C", text: "It increases by 120 fish each year." },
    { letter: "D", text: "It increases by 1.2 fish each year." } ] },
  // Q2 Advanced Math — sum of roots of quadratic
  { id: 2, prompt: "The quadratic equation 2x² − 12x + 7 = 0 has two solutions. What is the sum of the two solutions?", choices: [
    { letter: "A", text: "−6" }, { letter: "B", text: "3.5" }, { letter: "C", text: "6" }, { letter: "D", text: "12" } ] },
  // Q3 Geometry — circle equation
  { id: 3, prompt: "In the xy-plane, the equation of a circle is (x − 3)² + (y + 4)² = 25. What are the coordinates of the center and the length of the radius?", choices: [
    { letter: "A", text: "Center (3, −4), radius 5" },
    { letter: "B", text: "Center (−3, 4), radius 5" },
    { letter: "C", text: "Center (3, −4), radius 25" },
    { letter: "D", text: "Center (−3, 4), radius 25" } ] },
  // Q4 PSDA — word problem: weighted average / mixtures
  { id: 4, prompt: "A chemist needs to prepare 50 milliliters of a solution that is 30% acid by combining a 20% acid solution with a 50% acid solution. How many milliliters of the 50% acid solution should the chemist use?", choices: [
    { letter: "A", text: "150⁄9 ≈ 16.7" }, { letter: "B", text: "20" }, { letter: "C", text: "25" }, { letter: "D", text: "33.3" } ] },
  // Q5 Advanced Math — system of nonlinear equations
  { id: 5, prompt: "The system of equations y = x² − 2x + 1 and y = 2x − 3 is graphed in the xy-plane. How many points of intersection do the two graphs have?", choices: [
    { letter: "A", text: "0" }, { letter: "B", text: "1" }, { letter: "C", text: "2" }, { letter: "D", text: "Infinitely many" } ] },
  // Q6 PSDA — word problem: percent change over two steps
  { id: 6, prompt: "The price of a stock increased by 25% in its first year and then decreased by 20% in its second year. If the stock was worth $80 at the start of the first year, what was its value at the end of the second year, in dollars?", choices: [
    { letter: "A", text: "$76" }, { letter: "B", text: "$80" }, { letter: "C", text: "$84" }, { letter: "D", text: "$100" } ] },
  // Q7 Advanced Math — exponential decay word problem
  { id: 7, prompt: "A radioactive sample has a half-life of 8 years, meaning its mass is reduced by half every 8 years. If the sample initially has a mass of 240 grams, what is its mass, in grams, after 24 years?", choices: [
    { letter: "A", text: "30" }, { letter: "B", text: "40" }, { letter: "C", text: "60" }, { letter: "D", text: "80" } ] },
  // Q8 Trigonometry
  { id: 8, prompt: "In a right triangle, one of the acute angles measures θ, where sin θ = 3⁄5. What is the value of cos θ?", choices: [
    { letter: "A", text: "3⁄5" }, { letter: "B", text: "4⁄5" }, { letter: "C", text: "5⁄3" }, { letter: "D", text: "5⁄4" } ] },
  // Q9 PSDA — word problem: statistics (effect on mean/median)
  { id: 9, prompt: "A data set consists of the annual salaries of 9 employees at a small company, with a median of $52,000. The company hires a new executive with a salary of $480,000, creating a data set of 10 salaries. Which of the following statements is true about the new data set compared with the original?", choices: [
    { letter: "A", text: "The mean increases substantially, while the median changes very little." },
    { letter: "B", text: "Both the mean and the median increase substantially." },
    { letter: "C", text: "The mean stays the same, but the median increases." },
    { letter: "D", text: "Neither the mean nor the median changes." } ] },
  // Q10 Advanced Math: solve quadratic
  { id: 10, prompt: "If x² − 10x + 21 = 0 and x > 4, what is the value of x?", choices: [
    { letter: "A", text: "3" }, { letter: "B", text: "5" }, { letter: "C", text: "7" }, { letter: "D", text: "10" } ] },
  // Q11 Geometry — word problem: similar triangles / shadows
  { id: 11, prompt: "A 6-foot-tall person standing near a streetlight casts a shadow that is 9 feet long. At the same moment, a nearby flagpole casts a shadow that is 24 feet long. Assuming the light rays are parallel, what is the height of the flagpole, in feet?", choices: [
    { letter: "A", text: "16" }, { letter: "B", text: "21" }, { letter: "C", text: "27" }, { letter: "D", text: "36" } ] },
  // Q12 Advanced Math — exponent equation
  { id: 12, prompt: "If 3^(2x − 1) = 27, what is the value of x?", choices: [
    { letter: "A", text: "1" }, { letter: "B", text: "2" }, { letter: "C", text: "3" }, { letter: "D", text: "4" } ] },
  // Q13 PSDA — word problem: rates / combined work
  { id: 13, prompt: "Two pumps are used to fill a water tank. Working alone, the first pump can fill the tank in 6 hours and the second pump can fill it in 12 hours. If both pumps work together at their constant rates, how many hours will it take them to fill the tank?", choices: [
    { letter: "A", text: "2" }, { letter: "B", text: "4" }, { letter: "C", text: "8" }, { letter: "D", text: "9" } ] },
  // Q14 Advanced Math — vertex / completing the square
  { id: 14, prompt: "The function f is defined by f(x) = x² − 6x + 11. What is the minimum value of f(x)?", choices: [
    { letter: "A", text: "−6" }, { letter: "B", text: "2" }, { letter: "C", text: "3" }, { letter: "D", text: "11" } ] },
  // Q15 system of linear equations
  { id: 15, prompt: "A movie theater sold a total of 200 tickets for a showing, collecting $2,150 in revenue. Adult tickets cost $12 each and child tickets cost $7 each. How many adult tickets were sold?", choices: [
    { letter: "A", text: "70" }, { letter: "B", text: "130" }, { letter: "C", text: "150" }, { letter: "D", text: "170" } ] },
  // Q16 Trigonometry — radians / arc
  { id: 16, prompt: "An angle measures 3π⁄4 radians. What is the measure of this angle in degrees?", choices: [
    { letter: "A", text: "105°" }, { letter: "B", text: "120°" }, { letter: "C", text: "135°" }, { letter: "D", text: "150°" } ] },
  // Q17 Advanced Math — word problem: profit function (quadratic)
  { id: 17, prompt: "A company finds that its daily profit P, in dollars, from selling x units of a product is modeled by P(x) = −2x² + 80x − 350. According to the model, how many units must the company sell each day to maximize its daily profit?", choices: [
    { letter: "A", text: "10" }, { letter: "B", text: "20" }, { letter: "C", text: "40" }, { letter: "D", text: "80" } ] },
  // Q18 PSDA — word problem: linear growth / interpreting model
  { id: 18, prompt: "A gym charges a one-time sign-up fee plus a fixed monthly rate. A member who has belonged for 4 months has paid a total of $185, and a member who has belonged for 9 months has paid a total of $360. Based on a linear model, what is the gym's fixed monthly rate, in dollars?", choices: [
    { letter: "A", text: "$30" }, { letter: "B", text: "$35" }, { letter: "C", text: "$40" }, { letter: "D", text: "$45" } ] },
  // Q19 Geometry — volume word problem
  { id: 19, prompt: "A cylindrical water tank has a radius of 3 feet and a height of 10 feet. A second cylindrical tank has the same height but twice the radius. How many times greater is the volume of the second tank than the volume of the first tank?", choices: [
    { letter: "A", text: "2" }, { letter: "B", text: "4" }, { letter: "C", text: "6" }, { letter: "D", text: "8" } ] },
  // Q20 Advanced Math — rational equation
  { id: 20, prompt: "If (x + 2)⁄(x − 3) = 4, what is the value of x?", choices: [
    { letter: "A", text: "10⁄3" }, { letter: "B", text: "14⁄3" }, { letter: "C", text: "5" }, { letter: "D", text: "6" } ] },
  // Q21 exponential growth word problem
  { id: 21, prompt: "The number of users of a new app triples every month. If the app had 50 users at the end of its first month, how many users will it have at the end of its fourth month?", choices: [
    { letter: "A", text: "450" }, { letter: "B", text: "1,050" }, { letter: "C", text: "1,350" }, { letter: "D", text: "4,050" } ] },
  // Q22 PSDA word problem: density / unit conversion
  { id: 22, prompt: "A solid metal bar has a volume of 40 cubic centimeters and a density of 7.8 grams per cubic centimeter. What is the mass of the bar, in grams?", choices: [
    { letter: "A", text: "5.13" }, { letter: "B", text: "47.8" }, { letter: "C", text: "312" }, { letter: "D", text: "320" } ] },
]

export const modules: Module[] = [
  { section: 1, sectionName: "Reading and Writing", module: 1, moduleName: "Module 1", durationSeconds: 32 * 60, questions: rwModule1 },
  { section: 1, sectionName: "Reading and Writing", module: 2, moduleName: "Module 2", durationSeconds: 32 * 60, questions: rwModule2 },
  { section: 2, sectionName: "Math", module: 1, moduleName: "Module 1", durationSeconds: 35 * 60, questions: mathModule1 },
  { section: 2, sectionName: "Math", module: 2, moduleName: "Module 2", durationSeconds: 35 * 60, questions: mathModule2 },
]
