"use client"

import { useEffect, useRef, useState } from "react"
import { useRouter } from "next/navigation"

function BatteryIndicator() {
  return (
    <div className="flex items-center gap-1 text-xs text-neutral-700">
      <span>84%</span>
      <svg width="22" height="12" viewBox="0 0 22 12" fill="none" aria-hidden="true">
        <rect x="0.5" y="0.5" width="18" height="11" rx="2" stroke="currentColor" />
        <rect x="2" y="2" width="13" height="8" rx="1" fill="currentColor" />
        <rect x="20" y="3.5" width="1.5" height="5" rx="0.75" fill="currentColor" />
      </svg>
    </div>
  )
}

export default function StartCodePage() {
  const router = useRouter()
  const [digits, setDigits] = useState<string[]>(["", "", "", "", "", ""])
  const [error, setError] = useState("")
  const [submitting, setSubmitting] = useState(false)
  const [studentName, setStudentName] = useState("test")
  const inputs = useRef<(HTMLInputElement | null)[]>([])

  useEffect(() => {
    if (typeof window !== "undefined") {
      setStudentName(sessionStorage.getItem("sat_user") || "test")
    }
  }, [])

  function handleChange(index: number, value: string) {
    const v = value.replace(/\D/g, "").slice(-1)
    const next = [...digits]
    next[index] = v
    setDigits(next)
    setError("")
    if (v && index < 5) {
      inputs.current[index + 1]?.focus()
    }
  }

  function handleKeyDown(index: number, e: React.KeyboardEvent<HTMLInputElement>) {
    if (e.key === "Backspace" && !digits[index] && index > 0) {
      inputs.current[index - 1]?.focus()
    }
  }

  async function handleStart() {
    const code = digits.join("")
    setSubmitting(true)
    setError("")
    try {
      const res = await fetch("/api/start", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ code, name: studentName }),
      })
      if (!res.ok) {
        setError("Incorrect start code. Please check with your proctor and try again.")
        setSubmitting(false)
        return
      }
      // Go straight into the test, like the real SAT.
      router.push("/test")
    } catch {
      setError("Something went wrong. Please try again.")
      setSubmitting(false)
    }
  }

  return (
    <main className="flex min-h-screen flex-col bg-[#cfdfd0]">
      <header className="flex items-center justify-between bg-white px-6 py-3">
        <button className="flex items-center gap-2 text-sm font-medium text-neutral-800">
          <span className="flex h-6 w-6 items-center justify-center rounded-full border border-neutral-800 text-xs">
            ?
          </span>
          Help
        </button>
        <div className="flex items-center gap-6">
          <button className="flex items-center gap-2 text-sm font-medium text-neutral-800">
            Return to Home
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" aria-hidden="true">
              <path
                d="M3 11l9-7 9 7M5 10v9a1 1 0 001 1h4v-6h4v6h4a1 1 0 001-1v-9"
                stroke="currentColor"
                strokeWidth="1.6"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </svg>
          </button>
          <BatteryIndicator />
        </div>
      </header>

      <div className="flex flex-1 flex-col items-center px-4 pt-10 text-neutral-900">
        <h1 className="text-4xl font-bold text-black">Start Code</h1>
        <p className="mt-6 text-center text-lg text-black">
          Enter your start code now to begin testing. Good luck!
        </p>
        <p className="mt-1 text-center text-lg text-black">
          The start code contains <span className="font-bold">numbers only</span>.
        </p>

        <div className="mt-10 flex gap-3">
          {digits.map((d, i) => (
            <input
              key={i}
              ref={(el) => {
                inputs.current[i] = el
              }}
              value={d}
              inputMode="numeric"
              onChange={(e) => handleChange(i, e.target.value)}
              onKeyDown={(e) => handleKeyDown(i, e)}
              className="h-14 w-14 rounded-xl border-2 border-neutral-400 bg-white text-center text-3xl font-bold text-black outline-none transition-colors duration-200 focus:border-neutral-800"
            />
          ))}
        </div>

        {error ? <p className="mt-4 max-w-sm text-center text-sm text-red-600">{error}</p> : null}

        <button
          onClick={handleStart}
          disabled={submitting}
          className="mt-8 rounded-full border-2 border-black bg-[#ffd633] px-8 py-2.5 text-sm font-extrabold text-black hover:bg-[#f5cf2e] disabled:cursor-not-allowed disabled:opacity-60"
        >
          {submitting ? "Starting..." : "Start Test"}
        </button>

        <div className="mt-16 flex max-w-md items-center gap-4 rounded-xl bg-[#bcd2be] px-5 py-4">
          <div className="flex h-12 w-12 flex-shrink-0 items-center justify-center rounded-full bg-white">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" aria-hidden="true">
              <rect x="5" y="3" width="14" height="18" rx="2" stroke="#5b8fc7" strokeWidth="1.6" />
              <rect x="9" y="1.5" width="6" height="3" rx="1" fill="#5b8fc7" />
              <path d="M8 9h8M8 13h8M8 17h5" stroke="#5b8fc7" strokeWidth="1.4" strokeLinecap="round" />
            </svg>
          </div>
          <p className="text-sm text-neutral-800">
            You can{" "}
            <a href="#" className="text-blue-700 underline">
              review the instructions
            </a>
            <br />
            that the proctor reads aloud.
          </p>
        </div>
      </div>
    </main>
  )
}
