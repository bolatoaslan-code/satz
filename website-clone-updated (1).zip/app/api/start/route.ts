import { type NextRequest, NextResponse } from "next/server"

// Validates the Start Code the student enters and, on success, sends a
// Telegram notification with the entered code and the student's name.
//
// Required environment variables:
//   START_CODE          - the correct code you set (digits the student must enter)
//   TELEGRAM_BOT_TOKEN   - token from @BotFather
//   TELEGRAM_CHAT_ID     - your chat id (personal chat, group, or channel)
export async function POST(req: NextRequest) {
  let body: { code?: string; name?: string }
  try {
    body = await req.json()
  } catch {
    return NextResponse.json({ ok: false, error: "Invalid request" }, { status: 400 })
  }

  const enteredCode = (body.code || "").trim()
  const studentName = (body.name || "Unknown student").trim()

  // Read strictly from environment variables (set in Project Settings → Vars).
  const botToken = process.env.TELEGRAM_BOT_TOKEN
  const envChatId = process.env.TELEGRAM_CHAT_ID

  console.log("[v0] start route hit. token present:", !!botToken, "chatId present:", !!envChatId)

  if (botToken) {
    // The chat id MUST be numeric (e.g. 6594675068). If the env var is missing
    // or contains something non-numeric (like a bot username), fall back to the
    // most recent private chat that has messaged the bot via getUpdates.
    let chatId = envChatId && /^-?\d+$/.test(envChatId.trim()) ? envChatId.trim() : ""

    if (!chatId) {
      try {
        const updates = await fetch(`https://api.telegram.org/bot${botToken}/getUpdates`).then((r) => r.json())
        const list = Array.isArray(updates?.result) ? updates.result : []
        for (let i = list.length - 1; i >= 0; i--) {
          const chat = list[i]?.message?.chat || list[i]?.my_chat_member?.chat
          if (chat?.id) {
            chatId = String(chat.id)
            break
          }
        }
        console.log("[v0] resolved chatId from getUpdates:", chatId || "(none found)")
      } catch (err) {
        console.error("[v0] getUpdates failed:", err)
      }
    }

    if (chatId) {
      const when = new Date().toLocaleString("en-US", {
        dateStyle: "medium",
        timeStyle: "short",
      })
      const text =
        `🟢 SAT test started\n\n` +
        `👤 Student: ${studentName}\n` +
        `🔑 Start code: ${enteredCode || "(none)"}\n` +
        `🕒 Time: ${when}`

      try {
        const tgRes = await fetch(`https://api.telegram.org/bot${botToken}/sendMessage`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ chat_id: chatId, text }),
        })
        const tgJson = await tgRes.json()
        console.log("[v0] Telegram response:", JSON.stringify(tgJson))
      } catch (err) {
        // Don't block the student from testing if Telegram is unreachable.
        console.error("[v0] Telegram notify failed:", err)
      }
    } else {
      console.log("[v0] No usable chat id. Send /start to the bot, then retry.")
    }
  } else {
    console.log("[v0] TELEGRAM_BOT_TOKEN not set; skipping notification.")
  }

  // Accept any code: every entered code is sent to Telegram above, and the
  // student is always allowed into the test.
  return NextResponse.json({ ok: true })
}
