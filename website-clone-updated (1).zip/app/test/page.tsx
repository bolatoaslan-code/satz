"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { modules } from "@/lib/questions"
import { ModuleView } from "@/components/module-view"
import { BreakScreen, ModuleTransition } from "@/components/test-screens"

// Flow steps: m0 -> t0 -> m1 -> break -> m2 -> t1 -> m3 -> done
type Phase =
  | { type: "module"; index: number }
  | { type: "transition"; nextIndex: number }
  | { type: "break"; nextIndex: number }
  | { type: "done" }

export default function TestPage() {
  const router = useRouter()
  const [phase, setPhase] = useState<Phase>({ type: "module", index: 0 })
  const [user, setUser] = useState("test")

  useEffect(() => {
    if (typeof window !== "undefined") {
      setUser(sessionStorage.getItem("sat_user") || "test")
    }
  }, [])

  function finishModule(currentIndex: number) {
    // After RW Module 1 (index 0) -> transition into RW Module 2
    if (currentIndex === 0) {
      setPhase({ type: "transition", nextIndex: 1 })
    }
    // After RW Module 2 (index 1) -> Break, then Math Module 1
    else if (currentIndex === 1) {
      setPhase({ type: "break", nextIndex: 2 })
    }
    // After Math Module 1 (index 2) -> transition into Math Module 2
    else if (currentIndex === 2) {
      setPhase({ type: "transition", nextIndex: 3 })
    }
    // After Math Module 2 (index 3) -> Done
    else {
      setPhase({ type: "done" })
    }
  }

  if (phase.type === "module") {
    const mod = modules[phase.index]
    return <ModuleView mod={mod} user={user} onFinishModule={() => finishModule(phase.index)} />
  }

  if (phase.type === "transition") {
    return (
      <ModuleTransition
        title="This Module Is Over"
        onContinue={() => setPhase({ type: "module", index: phase.nextIndex })}
      />
    )
  }

  if (phase.type === "break") {
    return <BreakScreen onResume={() => setPhase({ type: "module", index: phase.nextIndex })} />
  }

  // done
  return <FinishedScreen onReturn={() => router.push("/start-code")} />
}

function FinishedScreen({ onReturn }: { onReturn: () => void }) {
  // Deterministic confetti pieces so the celebration matches the official Bluebook screen.
  const confetti = Array.from({ length: 70 }, (_, i) => {
    const colors = ["#f4c430", "#e8b923", "#f4a0b5", "#9fd3ef", "#f0d98a"]
    const seed = (i * 9301 + 49297) % 233280
    const rand = seed / 233280
    const seed2 = (i * 4391 + 13513) % 233280
    const rand2 = seed2 / 233280
    return {
      left: `${(rand * 100).toFixed(2)}%`,
      top: `${(rand2 * 100).toFixed(2)}%`,
      color: colors[i % colors.length],
      rotate: `${Math.floor(rand * 360)}deg`,
      w: i % 3 === 0 ? 6 : 8,
      h: i % 3 === 0 ? 10 : 6,
      round: i % 4 === 0,
    }
  })

  return (
    <main className="relative flex h-screen flex-col overflow-hidden bg-[#2b2f9e] text-white">
      {/* Confetti */}
      <div className="pointer-events-none absolute inset-0" aria-hidden="true">
        {confetti.map((c, i) => (
          <span
            key={i}
            className="absolute"
            style={{
              left: c.left,
              top: c.top,
              width: c.w,
              height: c.h,
              backgroundColor: c.color,
              borderRadius: c.round ? "9999px" : "1px",
              transform: `rotate(${c.rotate})`,
            }}
          />
        ))}
      </div>

      {/* Top bar — only "Return to Home" on the right, like the official screen */}
      <div className="relative z-10 flex items-center justify-end bg-white px-8 py-2.5">
        <button onClick={onReturn} className="flex items-center gap-2 text-sm font-medium text-neutral-800">
          Return to Home
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" aria-hidden="true">
            <path
              d="M4 11.5L12 5l8 6.5M6 10v9h12v-9"
              stroke="currentColor"
              strokeWidth="1.5"
              strokeLinejoin="round"
            />
          </svg>
        </button>
      </div>

      {/* Center content */}
      <div className="relative z-10 flex flex-1 flex-col items-center px-6 pt-16 pb-20">
        <h1 className="text-4xl font-bold text-balance">Congratulations!</h1>
        <p className="mt-4 text-center text-lg font-normal leading-relaxed text-pretty">
          Your test is complete, and your answers have been submitted.
        </p>

        <div className="mt-10 flex w-full max-w-2xl items-center gap-10 rounded-2xl bg-[#eef0f4] px-10 py-10 text-neutral-700 shadow-lg">
          <LaptopSmiley />
          <ul className="flex flex-col gap-5 text-base leading-relaxed">
            <li>
              <span className="font-bold">Raise your hand</span>, and your proctor will dismiss you.
            </li>
            <li>
              <span className="font-bold">Please be quiet</span>; other students may still be testing.
            </li>
            <li>
              Go to <span className="font-bold">My SAT</span> to see when your scores will be available.
            </li>
          </ul>
        </div>

        <button
          onClick={onReturn}
          className="mt-10 rounded-full bg-[#fdb913] px-8 py-3 text-base font-semibold text-[#1e1a6e] hover:bg-[#f0ad00]"
        >
          Return to Homepage
        </button>
      </div>
    </main>
  )
}

function LaptopSmiley() {
  return (
    <div className="relative flex-shrink-0">
      <svg width="190" height="150" viewBox="0 0 190 150" fill="none" aria-hidden="true">
        {/* laptop lid / screen */}
        <rect x="35" y="12" width="120" height="92" rx="8" fill="#ffffff" stroke="#8a93a6" strokeWidth="4" />
        {/* inner screen edge */}
        <rect x="46" y="22" width="98" height="72" rx="4" fill="#ffffff" stroke="#8a93a6" strokeWidth="2" />
        {/* faint blue circle behind smiley */}
        <circle cx="95" cy="58" r="26" fill="#d9ecf7" />
        {/* smiley eyes */}
        <circle cx="85" cy="52" r="3" fill="#5a6473" />
        <circle cx="105" cy="52" r="3" fill="#5a6473" />
        {/* smiley mouth */}
        <path d="M82 62c4 9 22 9 26 0" stroke="#5a6473" strokeWidth="3.5" strokeLinecap="round" fill="none" />
        {/* laptop base */}
        <path
          d="M18 112h154l12 22H6z"
          fill="#ffffff"
          stroke="#8a93a6"
          strokeWidth="4"
          strokeLinejoin="round"
        />
        {/* trackpad notch */}
        <path d="M78 122h34" stroke="#8a93a6" strokeWidth="4" strokeLinecap="round" />
      </svg>
    </div>
  )
}
