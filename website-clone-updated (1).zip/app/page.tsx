"use client"

import type React from "react"
import { useState } from "react"
import { useRouter } from "next/navigation"

export default function SignInPage() {
  const router = useRouter()
  const [login, setLogin] = useState("")
  const [password, setPassword] = useState("")
  const [error, setError] = useState("")

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    if (password !== "9009") {
      setError("Incorrect login or password. Please try again.")
      return
    }
    setError("")
    if (typeof window !== "undefined") {
      sessionStorage.setItem("sat_user", login || "test")
    }
    router.push("/start-code")
  }

  return (
    <main className="flex min-h-screen items-center justify-center bg-white px-4 text-neutral-900">
      <form onSubmit={handleSubmit} className="flex w-full max-w-md flex-col">
        <h1 className="mb-10 text-center text-4xl font-normal tracking-tight">Sign In</h1>

        <label className="mb-1 text-sm font-bold text-neutral-900">Login</label>
        <input
          type="text"
          value={login}
          onChange={(e) => setLogin(e.target.value)}
          placeholder="Enter your name"
          className="mb-6 w-full rounded-lg border border-neutral-400 px-4 py-3 text-base outline-none focus:border-neutral-600"
        />

        <label className="mb-1 text-sm font-bold text-neutral-900">Password</label>
        <input
          type="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          placeholder="Enter password"
          className="w-full rounded-lg border border-neutral-400 px-4 py-3 text-base outline-none focus:border-neutral-600"
        />

        {error ? <p className="mt-3 text-center text-sm text-red-600">{error}</p> : null}

        <button
          type="submit"
          className="mx-auto mt-10 rounded-lg bg-[#1e1a6e] px-10 py-3 text-base font-semibold text-white transition-colors hover:bg-[#171357]"
        >
          Sign In
        </button>
      </form>
    </main>
  )
}
