"use client"

import { useEffect, useState } from "react"

function useCountdown(initialSeconds: number, onEnd?: () => void) {
  const [seconds, setSeconds] = useState(initialSeconds)
  useEffect(() => {
    setSeconds(initialSeconds)
  }, [initialSeconds])
  useEffect(() => {
    const t = setInterval(() => {
      setSeconds((s) => {
        if (s <= 1) {
          clearInterval(t)
          onEnd?.()
          return 0
        }
        return s - 1
      })
    }, 1000)
    return () => clearInterval(t)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [initialSeconds])
  const m = Math.floor(seconds / 60)
  const s = seconds % 60
  return `${m}:${s.toString().padStart(2, "0")}`
}

// Black "Take a Break: Do Not Close Your Device" screen with a 10-minute countdown.
export function BreakScreen({ onResume }: { onResume: () => void }) {
  const [canResume, setCanResume] = useState(false)
  const time = useCountdown(10 * 60, () => setCanResume(true))

  return (
    <main className="flex h-screen flex-col bg-neutral-950 text-white">
      <div className="flex items-center justify-end px-6 py-4">
        <div className="flex items-center gap-1 rounded bg-neutral-800 px-3 py-1.5 text-sm font-medium">
          <span>84%</span>
          <svg width="22" height="12" viewBox="0 0 22 12" fill="none" aria-hidden="true">
            <rect x="0.5" y="0.5" width="18" height="11" rx="2" stroke="currentColor" />
            <rect x="2" y="2" width="13" height="8" rx="1" fill="currentColor" />
            <rect x="20" y="3.5" width="1.5" height="5" rx="0.75" fill="currentColor" />
          </svg>
        </div>
      </div>

      <div className="grid flex-1 grid-cols-1 items-center gap-10 px-10 pb-16 md:grid-cols-2 md:px-20">
        {/* Left: timer */}
        <div className="flex justify-center md:justify-start md:pl-10">
          <div className="rounded-md border-2 border-white px-12 py-8 text-center">
            <p className="text-2xl font-medium">Remaining Break Time:</p>
            <p className="mt-2 text-8xl font-bold tabular-nums">{time}</p>
          </div>
        </div>

        {/* Right: instructions */}
        <div className="max-w-xl">
          <h1 className="text-5xl font-bold leading-tight text-balance">Take a Break: Do Not Close Your Device</h1>
          <p className="mt-8 text-xl leading-relaxed">
            After the break, a <span className="font-bold">Resume Testing Now</span> button will appear and you&apos;ll
            start the next section.
          </p>
          <p className="mt-6 text-xl leading-relaxed">Be ready to continue when the button appears.</p>
          <p className="mt-6 text-xl font-bold">Follow these rules during the break:</p>
          <ol className="mt-4 list-decimal space-y-4 pl-6 text-lg leading-relaxed">
            <li>Do not disturb students who are still testing and remain quiet at all times.</li>
            <li>Do not exit the app or close your laptop.</li>
            <li>Do not access phones, smartwatches, textbooks, notes, or the internet.</li>
            <li>Do not eat or drink near any testing device.</li>
          </ol>

          {canResume ? (
            <button
              onClick={onResume}
              className="mt-10 rounded-full bg-white px-10 py-3 text-base font-semibold text-neutral-950 hover:bg-neutral-200"
            >
              Resume Testing Now
            </button>
          ) : (
            <button
              onClick={onResume}
              className="mt-10 rounded-full border border-neutral-600 px-10 py-3 text-base font-semibold text-neutral-400 hover:text-white"
            >
              Resume Testing Now
            </button>
          )}
        </div>
      </div>
    </main>
  )
}

// "This Module Is Over" screen with a spinner that auto-advances after a moment.
export function ModuleTransition({
  title,
  onContinue,
}: {
  title: string
  onContinue: () => void
}) {
  useEffect(() => {
    const t = setTimeout(onContinue, 3500)
    return () => clearTimeout(t)
  }, [onContinue])

  return (
    <main className="flex h-screen flex-col items-center justify-center bg-white px-6 text-center text-neutral-800">
      <h1 className="mb-10 text-[2.75rem] font-semibold leading-tight text-[#324dc7] text-balance">{title}</h1>
      <div className="space-y-2">
        <p className="text-xl font-normal leading-relaxed">All your work has been saved.</p>
        <p className="text-xl font-normal leading-relaxed">You&apos;ll move on automatically in just a moment.</p>
        <p className="text-xl font-normal leading-relaxed">Do not refresh this page or quit the app.</p>
      </div>
      <div className="mt-14 h-11 w-11 animate-spin rounded-full border-[3px] border-neutral-200 border-t-neutral-400" />
    </main>
  )
}
