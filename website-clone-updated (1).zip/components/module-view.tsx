"use client"

import { useEffect, useRef, useState } from "react"
import type { Module } from "@/lib/questions"
import { QuestionNavigator } from "@/components/question-navigator"

function useCountdown(initialSeconds: number, onEnd?: () => void) {
  const [seconds, setSeconds] = useState(initialSeconds)
  useEffect(() => {
    setSeconds(initialSeconds)
  }, [initialSeconds])
  useEffect(() => {
    const t = setInterval(() => {
      setSeconds((s) => {
        if (s <= 1) {
          clearInterval(t)
          onEnd?.()
          return 0
        }
        return s - 1
      })
    }, 1000)
    return () => clearInterval(t)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [initialSeconds])
  const m = Math.floor(seconds / 60)
  const s = seconds % 60
  return { display: `${m}:${s.toString().padStart(2, "0")}` }
}

function BatteryIndicator() {
  return (
    <div className="flex items-center gap-1 text-xs font-medium text-neutral-700">
      <span>84%</span>
      <svg width="22" height="12" viewBox="0 0 22 12" fill="none" aria-hidden="true">
        <rect x="0.5" y="0.5" width="18" height="11" rx="2" stroke="currentColor" />
        <rect x="2" y="2" width="13" height="8" rx="1" fill="currentColor" />
        <rect x="20" y="3.5" width="1.5" height="5" rx="0.75" fill="currentColor" />
      </svg>
    </div>
  )
}

// Decorative multicolor segmented bar (tan / green / blue / rust) shown as
// dividers throughout the test body, matching the reference SAT interface.
const BAR_COLORS = [
  "#c2632e", // rust/orange
  "#3e9e4e", // green
  "#2456a6", // blue
  "#9e3320", // dark red
  "#c9a14a", // gold/tan
  "#1a2e6e", // navy
  "#6f6f6f", // gray
]
// Deterministic varying-width segments so the bar looks organic, not uniform.
const BAR_WIDTHS = [
  3, 1.5, 2.5, 1.2, 2, 3.2, 1.4, 2.6, 1.8, 2.2, 1.3, 3, 1.6, 2.4, 1.1, 2.8, 1.9, 2.1, 1.5, 3.1, 1.3,
  2.7, 1.7, 2.3, 1.2, 2.9, 1.6, 2,
]

// Deterministic non-repeating color order so the bar looks like the real SAT bar.
const BAR_COLOR_ORDER = [
  0, 4, 1, 3, 2, 5, 0, 6, 1, 3, 4, 2, 0, 5, 1, 6, 3, 2, 4, 0, 1, 5, 3, 6, 2, 0, 4, 1,
]

function SegmentedBar() {
  return (
    <div className="flex h-[3px] w-full overflow-hidden" aria-hidden="true">
      {BAR_WIDTHS.map((w, i) => (
        <span
          key={i}
          style={{ flexGrow: w, backgroundColor: BAR_COLORS[BAR_COLOR_ORDER[i % BAR_COLOR_ORDER.length]] }}
        />
      ))}
    </div>
  )
}

export function ModuleView({
  mod,
  user,
  onFinishModule,
}: {
  mod: Module
  user: string
  onFinishModule: () => void
}) {
  const { display: time } = useCountdown(mod.durationSeconds)
  const [index, setIndex] = useState(0)
  const [answers, setAnswers] = useState<Record<number, string>>({})
  const [marked, setMarked] = useState<Record<number, boolean>>({})
  const [navOpen, setNavOpen] = useState(false)
  const [timerHidden, setTimerHidden] = useState(false)
  const [leftPct, setLeftPct] = useState(50)
  const [calcOpen, setCalcOpen] = useState(false)
  const [refOpen, setRefOpen] = useState(false)
  const dragging = useRef(false)

  // reset state when module changes
  useEffect(() => {
    setIndex(0)
    setAnswers({})
    setMarked({})
    setNavOpen(false)
    setLeftPct(50)
  }, [mod])

  // drag handlers for the split divider
  useEffect(() => {
    function onMove(e: MouseEvent) {
      if (!dragging.current) return
      const pct = (e.clientX / window.innerWidth) * 100
      setLeftPct(Math.min(75, Math.max(25, pct)))
    }
    function onUp() {
      dragging.current = false
      document.body.style.userSelect = ""
    }
    window.addEventListener("mousemove", onMove)
    window.addEventListener("mouseup", onUp)
    return () => {
      window.removeEventListener("mousemove", onMove)
      window.removeEventListener("mouseup", onUp)
    }
  }, [])

  const q = mod.questions[index]
  const selected = answers[q.id]
  const headerTitle = `Section ${mod.section}, ${mod.moduleName}: ${mod.sectionName}`
  const isReading = mod.section === 1

  function selectAnswer(letter: string) {
    setAnswers((a) => ({ ...a, [q.id]: letter }))
  }
  function toggleMark() {
    setMarked((m) => ({ ...m, [q.id]: !m[q.id] }))
  }

  function renderPassage(text: string) {
    // Render line breaks (used by Text 1 / Text 2, bulleted notes, data tables)
    // and the fill-in-the-blank underline used by words-in-context questions.
    const lines = text.split("\n")
    return lines.map((line, lineIdx) => {
      const parts = line.split("__________")
      return (
        <span key={lineIdx}>
          {parts.map((part, i) => (
            <span key={i}>
              {part}
              {i < parts.length - 1 ? (
                <span className="inline-block w-28 border-b border-neutral-800 align-middle" />
              ) : null}
            </span>
          ))}
          {lineIdx < lines.length - 1 ? <br /> : null}
        </span>
      )
    })
  }

  return (
    <main className="flex h-screen flex-col bg-white text-neutral-900">
      {/* Header */}
      <header className="relative flex items-center justify-between px-5 pt-3 pb-1">
        <div className="flex flex-col gap-1">
          <span className="text-base font-bold">{headerTitle}</span>
          <button className="flex w-fit items-center gap-1 text-sm font-medium">
            Directions
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none">
              <path d="M6 9l6 6 6-6" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
            </svg>
          </button>
        </div>

        <div className="pointer-events-none absolute left-1/2 top-3 flex -translate-x-1/2 flex-col items-center">
          {!timerHidden ? (
            <span className="text-2xl font-bold tabular-nums">{time}</span>
          ) : (
            <span className="flex h-8 items-center py-1 text-neutral-900" aria-label="Timer hidden">
              <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
                <circle cx="12" cy="13" r="8" stroke="currentColor" strokeWidth="1.8" />
                <path d="M12 9.5V13l2.5 2" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" />
                <path d="M9 3h6" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" />
              </svg>
            </span>
          )}
          <button
            onClick={() => setTimerHidden((h) => !h)}
            className="pointer-events-auto rounded-full border border-neutral-800 px-4 py-0.5 text-xs font-medium"
          >
            {timerHidden ? "Show" : "Hide"}
          </button>
        </div>

        <div className="flex flex-col items-end gap-1">
          <BatteryIndicator />
          <div className="flex items-end gap-5">
            {!isReading ? (
              <div className="flex items-center gap-4">
              <button
                onClick={() => setCalcOpen((o) => !o)}
                className="flex flex-col items-center text-xs font-medium"
              >
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" aria-hidden="true">
                  <rect x="5" y="2" width="14" height="20" rx="2" stroke="currentColor" strokeWidth="1.5" />
                  <rect x="7.5" y="4.5" width="9" height="3.5" rx="0.5" stroke="currentColor" strokeWidth="1.2" />
                  <circle cx="9" cy="12" r="1" fill="currentColor" />
                  <circle cx="12" cy="12" r="1" fill="currentColor" />
                  <circle cx="15" cy="12" r="1" fill="currentColor" />
                  <circle cx="9" cy="15.5" r="1" fill="currentColor" />
                  <circle cx="12" cy="15.5" r="1" fill="currentColor" />
                  <circle cx="15" cy="15.5" r="1" fill="currentColor" />
                  <circle cx="9" cy="19" r="1" fill="currentColor" />
                  <circle cx="12" cy="19" r="1" fill="currentColor" />
                  <circle cx="15" cy="19" r="1" fill="currentColor" />
                </svg>
                Calculator
              </button>
              <button
                onClick={() => setRefOpen((o) => !o)}
                className="flex flex-col items-center text-xs font-medium"
              >
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" aria-hidden="true">
                  <path d="M4 19V5a1 1 0 011-1h12a1 1 0 011 1v14" stroke="currentColor" strokeWidth="1.5" />
                  <path d="M4 19a2 2 0 002 2h12" stroke="currentColor" strokeWidth="1.5" />
                  <path d="M8 8h6M8 11h6" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" />
                </svg>
                Reference
              </button>
            </div>
          ) : null}
          <div className="flex items-end gap-6">
            {isReading ? (
              <div className="flex flex-col items-center">
                <div className="mb-0.5 flex items-center gap-3 text-neutral-900">
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" aria-hidden="true">
                    <path
                      d="M14.5 3.5l6 6-8.5 8.5H6v-6L14.5 3.5z"
                      stroke="currentColor"
                      strokeWidth="1.5"
                      strokeLinejoin="round"
                    />
                    <path d="M12.5 5.5l6 6" stroke="currentColor" strokeWidth="1.5" />
                    <path d="M4 21h16" stroke="#e0b400" strokeWidth="2.5" strokeLinecap="round" />
                  </svg>
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" aria-hidden="true">
                    <path
                      d="M5 3.5h10l4 4V20a0.5 0.5 0 01-.5.5h-13A0.5 0.5 0 015 20V3.5z"
                      stroke="currentColor"
                      strokeWidth="1.5"
                      strokeLinejoin="round"
                    />
                    <path d="M14.5 3.5V8h4.5" stroke="currentColor" strokeWidth="1.5" strokeLinejoin="round" />
                    <path d="M8 12h8M8 15.5h8" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round" />
                  </svg>
                </div>
                <span className="border-b-2 border-neutral-900 text-sm font-semibold text-black">
                  Highlights &amp; Notes
                </span>
              </div>
            ) : null}
            <button className="flex flex-col items-center text-sm font-semibold text-black">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" aria-hidden="true">
                <circle cx="5" cy="12" r="2" fill="currentColor" />
                <circle cx="12" cy="12" r="2" fill="currentColor" />
                <circle cx="19" cy="12" r="2" fill="currentColor" />
              </svg>
              More
            </button>
          </div>
          </div>
        </div>
      </header>

      <SegmentedBar />

      {/* Body */}
      {isReading ? (
        <div className="relative flex flex-1 overflow-hidden">
          {/* Left: passage */}
          <div className="overflow-y-auto px-12 py-8" style={{ width: `${leftPct}%` }}>
            <p className="font-serif text-lg font-normal leading-relaxed text-black">{renderPassage(q.passage ?? "")}</p>
          </div>

          {/* Divider with drag handle */}
          <div className="relative w-px bg-neutral-300">
            <button
              aria-label="Resize panels"
              onMouseDown={() => {
                dragging.current = true
                document.body.style.userSelect = "none"
              }}
              className="absolute left-1/2 flex h-6 w-3.5 -translate-x-1/2 -translate-y-1/2 cursor-col-resize items-center justify-center rounded bg-neutral-900 text-white"
              style={{ top: "30%" }}
            >
              <span className="text-[7px] leading-none">◀▶</span>
            </button>
          </div>

          {/* Right: question */}
          <div className="flex-1 overflow-y-auto px-10 py-6">
            <QuestionHeader id={q.id} marked={!!marked[q.id]} onToggleMark={toggleMark} />
            <p className="mb-5 font-serif text-lg font-normal leading-relaxed text-black">{q.prompt}</p>
            <Choices choices={q.choices ?? []} selected={selected} onSelect={selectAnswer} />
          </div>
        </div>
      ) : (
        <div className="mx-auto flex w-full max-w-3xl flex-1 flex-col overflow-y-auto px-8 py-6">
          <QuestionHeader id={q.id} marked={!!marked[q.id]} onToggleMark={toggleMark} />
          <p className="mb-6 font-serif text-lg font-normal leading-relaxed text-black">{q.prompt}</p>
          {q.choices && q.choices.length > 0 ? (
            <Choices choices={q.choices} selected={selected} onSelect={selectAnswer} />
          ) : (
            <SprInput value={selected ?? ""} onChange={(v) => setAnswers((a) => ({ ...a, [q.id]: v }))} />
          )}
        </div>
      )}

      <SegmentedBar />

      {/* Footer */}
      <footer className="relative flex items-center justify-between bg-white px-6 py-3">
        <span className="text-lg font-bold">{user}</span>

        <button
          onClick={() => setNavOpen((o) => !o)}
          className="flex items-center gap-2 rounded-lg bg-neutral-900 px-5 py-2.5 text-sm font-semibold text-white"
        >
          Question {q.id} of {mod.questions.length}
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none">
            <path d="M6 15l6-6 6 6" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
          </svg>
        </button>

        <div className="flex gap-3">
          {index > 0 ? (
            <button
              onClick={() => setIndex((i) => i - 1)}
              className="rounded-full bg-[#1e1a6e] px-8 py-2.5 text-sm font-semibold text-white hover:bg-[#171357]"
            >
              Back
            </button>
          ) : null}
          {index < mod.questions.length - 1 ? (
            <button
              onClick={() => setIndex((i) => i + 1)}
              className="rounded-full bg-[#1e1a6e] px-8 py-2.5 text-sm font-semibold text-white hover:bg-[#171357]"
            >
              Next
            </button>
          ) : (
            <button
              onClick={onFinishModule}
              className="rounded-full bg-[#1e1a6e] px-8 py-2.5 text-sm font-semibold text-white hover:bg-[#171357]"
            >
              Next
            </button>
          )}
        </div>

        {navOpen ? (
          <QuestionNavigator
            title={`${headerTitle} Questions`}
            questions={mod.questions}
            current={index}
            answers={answers}
            marked={marked}
            onSelect={(i) => {
              setIndex(i)
              setNavOpen(false)
            }}
            onClose={() => setNavOpen(false)}
          />
        ) : null}
      </footer>

      {calcOpen ? <CalculatorPanel onClose={() => setCalcOpen(false)} /> : null}
      {refOpen ? <ReferencePanel onClose={() => setRefOpen(false)} /> : null}
    </main>
  )
}

function QuestionHeader({
  id,
  marked,
  onToggleMark,
}: {
  id: number
  marked: boolean
  onToggleMark: () => void
}) {
  return (
    <div className="mb-5">
      <div className="flex items-center justify-between bg-neutral-100 px-3 py-2">
        <div className="flex items-center gap-3">
          <span className="flex h-8 w-8 items-center justify-center bg-neutral-900 text-base font-bold text-white">
            {id}
          </span>
          <button onClick={onToggleMark} className="flex items-center gap-2 text-base">
            <svg width="18" height="20" viewBox="0 0 12 14" aria-hidden="true">
              <path d="M0 0h12v14l-6-4-6 4V0z" fill={marked ? "#c0392b" : "none"} stroke="#333" strokeWidth="1" />
            </svg>
            Mark for Review
          </button>
        </div>
        <button
          aria-label="Text to speech"
          className="flex h-8 w-8 items-center justify-center rounded bg-blue-700 text-[11px] font-bold text-white"
        >
          ABC
        </button>
      </div>
      <SegmentedBar />
    </div>
  )
}

function CalculatorPanel({ onClose }: { onClose: () => void }) {
  const elRef = useRef<HTMLDivElement | null>(null)
  const calcRef = useRef<any>(null)
  const [expanded, setExpanded] = useState(false)

  useEffect(() => {
    let cancelled = false
    const SRC = "https://www.desmos.com/api/v1.11/calculator.js?apiKey=dcb31709b452b1cf9dc26972add0fda6"

    function init() {
      if (cancelled || !elRef.current) return
      const Desmos = (window as any).Desmos
      if (!Desmos) return
      calcRef.current = Desmos.GraphingCalculator(elRef.current, {
        keypad: true,
        expressions: true,
        settingsMenu: true,
        zoomButtons: true,
        border: false,
      })
    }

    const existing = document.querySelector<HTMLScriptElement>(`script[src="${SRC}"]`)
    if ((window as any).Desmos) {
      init()
    } else if (existing) {
      existing.addEventListener("load", init)
    } else {
      const s = document.createElement("script")
      s.src = SRC
      s.async = true
      s.addEventListener("load", init)
      document.body.appendChild(s)
    }

    return () => {
      cancelled = true
      if (calcRef.current) {
        calcRef.current.destroy()
        calcRef.current = null
      }
    }
  }, [])

  return (
    <div
      className={`fixed left-4 top-24 z-50 overflow-hidden rounded-lg border border-neutral-300 bg-white shadow-2xl ${
        expanded ? "w-[640px]" : "w-[420px]"
      } max-w-[92vw]`}
    >
      <div className="flex cursor-move items-center justify-between bg-neutral-900 px-3 py-2 text-white">
        <span className="text-sm font-semibold">Calculator</span>
        <div className="flex items-center gap-3">
          <button
            onClick={() => setExpanded((e) => !e)}
            aria-label="Expand calculator"
            className="text-neutral-300 hover:text-white"
          >
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
              <path
                d="M9 4H4v5M15 4h5v5M9 20H4v-5M15 20h5v-5"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </svg>
          </button>
          <button onClick={onClose} aria-label="Close calculator" className="text-neutral-300 hover:text-white">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
              <path d="M6 6l12 12M18 6L6 18" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
            </svg>
          </button>
        </div>
      </div>
      <div ref={elRef} className={`${expanded ? "h-[560px]" : "h-[480px]"} w-full`} />
    </div>
  )
}

function ReferencePanel({ onClose }: { onClose: () => void }) {
  return (
    <div className="fixed right-4 top-24 z-50 w-[560px] max-w-[92vw] overflow-hidden rounded-lg border border-neutral-300 bg-white shadow-2xl">
      <div className="flex items-center justify-between bg-neutral-100 px-3 py-1.5">
        <span className="text-sm font-semibold">Reference Sheet</span>
        <button onClick={onClose} aria-label="Close reference" className="text-neutral-600 hover:text-neutral-900">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
            <path d="M6 6l12 12M18 6L6 18" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
          </svg>
        </button>
      </div>
      <div className="max-h-[72vh] overflow-y-auto px-5 py-6">
        <div className="grid grid-cols-3 gap-x-4 gap-y-7 text-center text-[13px] text-black">
          <RefItem formula="A = πr²">
            <svg width="58" height="46" viewBox="0 0 58 46">
              <circle cx="29" cy="23" r="17" fill="none" stroke="black" strokeWidth="1.3" />
              <line x1="29" y1="23" x2="46" y2="23" stroke="black" strokeWidth="1.3" />
              <text x="36" y="20" fontSize="9">r</text>
            </svg>
          </RefItem>
          <RefItem formula="C = 2πr">
            <svg width="58" height="46" viewBox="0 0 58 46">
              <circle cx="29" cy="23" r="17" fill="none" stroke="black" strokeWidth="1.3" />
              <line x1="29" y1="23" x2="46" y2="23" stroke="black" strokeWidth="1.3" />
              <text x="36" y="20" fontSize="9">r</text>
            </svg>
          </RefItem>
          <RefItem formula="A = ℓw">
            <svg width="64" height="46" viewBox="0 0 64 46">
              <rect x="10" y="12" width="44" height="24" fill="none" stroke="black" strokeWidth="1.3" />
              <text x="30" y="9" fontSize="9">ℓ</text>
              <text x="2" y="27" fontSize="9">w</text>
            </svg>
          </RefItem>
          <RefItem formula="A = ½bh">
            <svg width="64" height="46" viewBox="0 0 64 46">
              <polygon points="10,38 54,38 34,8" fill="none" stroke="black" strokeWidth="1.3" />
              <line x1="34" y1="8" x2="34" y2="38" stroke="black" strokeWidth="0.8" strokeDasharray="2 2" />
              <text x="30" y="46" fontSize="9">b</text>
              <text x="36" y="26" fontSize="9">h</text>
            </svg>
          </RefItem>
          <RefItem formula="c² = a² + b²">
            <svg width="64" height="46" viewBox="0 0 64 46">
              <polygon points="12,38 12,10 50,38" fill="none" stroke="black" strokeWidth="1.3" />
              <rect x="12" y="32" width="6" height="6" fill="none" stroke="black" strokeWidth="0.8" />
              <text x="2" y="26" fontSize="9">a</text>
              <text x="30" y="46" fontSize="9">b</text>
              <text x="34" y="22" fontSize="9">c</text>
            </svg>
          </RefItem>
          <RefItem formula="">
            <svg width="74" height="50" viewBox="0 0 74 50">
              <polygon points="12,42 42,42 12,16" fill="none" stroke="black" strokeWidth="1.3" />
              <text x="20" y="50" fontSize="9">x</text>
              <text x="2" y="32" fontSize="9">x</text>
              <text x="26" y="28" fontSize="9">x√2</text>
              <text x="14" y="22" fontSize="8">45°</text>
            </svg>
          </RefItem>
          <RefItem formula="">
            <svg width="74" height="50" viewBox="0 0 74 50">
              <polygon points="12,42 54,42 12,12" fill="none" stroke="black" strokeWidth="1.3" />
              <text x="28" y="50" fontSize="9">x√3</text>
              <text x="2" y="30" fontSize="9">x</text>
              <text x="30" y="26" fontSize="9">2x</text>
              <text x="16" y="22" fontSize="8">30°</text>
            </svg>
          </RefItem>
          <RefItem formula="V = ℓwh">
            <svg width="70" height="50" viewBox="0 0 70 50">
              <rect x="12" y="16" width="34" height="22" fill="none" stroke="black" strokeWidth="1.3" />
              <path d="M12 16 L24 6 L58 6 L46 16 M46 38 L58 28 L58 6" fill="none" stroke="black" strokeWidth="1.3" />
            </svg>
          </RefItem>
          <RefItem formula="V = πr²h">
            <svg width="60" height="50" viewBox="0 0 60 50">
              <ellipse cx="30" cy="12" rx="16" ry="5" fill="none" stroke="black" strokeWidth="1.3" />
              <path d="M14 12 V38 M46 12 V38" stroke="black" strokeWidth="1.3" />
              <path d="M14 38 a16 5 0 0 0 32 0" fill="none" stroke="black" strokeWidth="1.3" />
            </svg>
          </RefItem>
          <RefItem formula="V = ⁴⁄₃πr³">
            <svg width="56" height="50" viewBox="0 0 56 50">
              <circle cx="28" cy="25" r="17" fill="none" stroke="black" strokeWidth="1.3" />
              <ellipse cx="28" cy="25" rx="17" ry="6" fill="none" stroke="black" strokeWidth="0.8" />
            </svg>
          </RefItem>
          <RefItem formula="V = ⅓πr²h">
            <svg width="56" height="50" viewBox="0 0 56 50">
              <path d="M10 40 L28 6 L46 40" fill="none" stroke="black" strokeWidth="1.3" />
              <ellipse cx="28" cy="40" rx="18" ry="5" fill="none" stroke="black" strokeWidth="1.3" />
            </svg>
          </RefItem>
          <RefItem formula="V = ⅓ℓwh">
            <svg width="60" height="50" viewBox="0 0 60 50">
              <path d="M30 6 L10 40 L50 40 Z" fill="none" stroke="black" strokeWidth="1.3" />
              <path d="M30 6 L40 32 L10 40 M40 32 L50 40" fill="none" stroke="black" strokeWidth="0.9" />
            </svg>
          </RefItem>
        </div>
        <div className="mt-6 space-y-1.5 border-t border-neutral-200 pt-4 text-[13px] leading-relaxed text-black">
          <p>The number of degrees of arc in a circle is 360.</p>
          <p>The number of radians of arc in a circle is 2π.</p>
          <p>The sum of the measures in degrees of the angles of a triangle is 180.</p>
        </div>
      </div>
    </div>
  )
}

function RefItem({ children, formula }: { children: React.ReactNode; formula: string }) {
  return (
    <div className="flex flex-col items-center justify-end gap-1">
      <div className="flex h-[50px] items-end justify-center">{children}</div>
      {formula ? <span className="font-serif">{formula}</span> : null}
    </div>
  )
}

function SprInput({ value, onChange }: { value: string; onChange: (v: string) => void }) {
  return (
    <div className="max-w-md">
      <input
        type="text"
        inputMode="text"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder="Enter answer"
        aria-label="Student-produced response answer"
        className="w-full rounded-lg border-2 border-neutral-800 bg-white px-4 py-3 font-serif text-lg text-black outline-none focus:border-[#324dc7]"
      />
      <div className="mt-3 rounded-lg bg-neutral-100 px-4 py-3 text-sm leading-relaxed text-neutral-700">
        <p className="font-semibold">Answer Preview</p>
        <p className="font-serif text-base text-black">{value || "—"}</p>
      </div>
    </div>
  )
}

function Choices({
  choices,
  selected,
  onSelect,
}: {
  choices: { letter: string; text: string }[]
  selected?: string
  onSelect: (letter: string) => void
}) {
  return (
    <div className="flex flex-col gap-3">
      {choices.map((c) => {
        const isSel = selected === c.letter
        return (
          <button
            key={c.letter}
            onClick={() => onSelect(c.letter)}
            className={`flex items-center gap-3 rounded-xl px-4 py-3 text-left font-serif text-base font-normal text-black transition-colors ${
              isSel
                ? "border-[3px] border-[#324dc7] bg-white"
                : "border-2 border-neutral-800 hover:border-blue-400"
            }`}
          >
            <span
              className={`flex h-7 w-7 flex-shrink-0 items-center justify-center rounded-full text-sm font-bold ${
                isSel ? "bg-[#324dc7] text-white" : "border-2 border-neutral-900 text-black"
              }`}
            >
              {c.letter}
            </span>
            <span>{c.text}</span>
          </button>
        )
      })}
    </div>
  )
}
