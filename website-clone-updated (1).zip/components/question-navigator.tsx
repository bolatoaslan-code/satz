"use client"

import type { Question } from "@/lib/questions"

export function QuestionNavigator({
  title,
  questions,
  current,
  answers,
  marked,
  onSelect,
  onClose,
}: {
  title: string
  questions: Question[]
  current: number
  answers: Record<number, string>
  marked: Record<number, boolean>
  onSelect: (index: number) => void
  onClose: () => void
}) {
  return (
    <>
      <div className="fixed inset-0 z-40" onClick={onClose} />
      <div className="absolute bottom-20 left-1/2 z-50 w-[460px] -translate-x-1/2 rounded-lg border border-neutral-300 bg-white p-5 shadow-2xl">
        <button
          onClick={onClose}
          aria-label="Close"
          className="absolute right-3 top-3 text-neutral-500 hover:text-neutral-800"
        >
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
            <path d="M6 6l12 12M18 6L6 18" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
          </svg>
        </button>
        <h2 className="text-center text-base font-bold text-neutral-900">{title}</h2>
        <div className="my-3 border-t border-neutral-200" />
        <div className="mb-4 flex items-center justify-center gap-6 text-xs text-neutral-700">
          <span className="flex items-center gap-1.5">
            <span className="flex h-4 w-4 items-center justify-center rounded-full border border-neutral-700 text-[8px]">
              ◉
            </span>
            Current
          </span>
          <span className="flex items-center gap-1.5">
            <span className="h-3.5 w-3.5 rounded-sm border border-dashed border-neutral-500" />
            Unanswered
          </span>
          <span className="flex items-center gap-1.5">
            <svg width="12" height="14" viewBox="0 0 12 14" aria-hidden="true">
              <path d="M0 0h12v14l-6-4-6 4V0z" fill="#c0392b" />
            </svg>
            For Review
          </span>
        </div>

        <div className="grid grid-cols-9 gap-2">
          {questions.map((q, i) => {
            const isCurrent = i === current
            const answered = answers[q.id] !== undefined
            const isMarked = marked[q.id]
            return (
              <button
                key={q.id}
                onClick={() => onSelect(i)}
                className={`relative flex h-9 w-9 items-center justify-center rounded text-sm font-medium ${
                  isCurrent
                    ? "border-2 border-blue-700 text-blue-700"
                    : answered
                      ? "bg-blue-700 text-white"
                      : "border border-dashed border-neutral-400 text-blue-700"
                }`}
              >
                {q.id}
                {isMarked ? (
                  <svg
                    width="9"
                    height="11"
                    viewBox="0 0 12 14"
                    className="absolute -right-1 -top-1"
                    aria-hidden="true"
                  >
                    <path d="M0 0h12v14l-6-4-6 4V0z" fill="#c0392b" />
                  </svg>
                ) : null}
              </button>
            )
          })}
        </div>

        <div className="mt-5 flex justify-center">
          <button className="rounded-full border-2 border-blue-700 px-6 py-1.5 text-sm font-semibold text-blue-700 hover:bg-blue-50">
            Go to Review Page
          </button>
        </div>
      </div>
    </>
  )
}
